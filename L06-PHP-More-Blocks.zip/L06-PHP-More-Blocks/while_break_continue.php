<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>While, Break & Continue Examples for Learning PHP and MySQL class</title>
    <!-- Introduction
    1. There are 4 sections total added to a vscode HTML 5 blank page. 
      - Each has BEGIN, END 
    2. These instructions are downloaded from https://github.com/mgoto2022/2nd-Level-Class-Notes
    -->
    <!-- 1.BEGIN PAGE CSS STYLE BEGIN -->
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .code {
        float: left;
        font-size: 20px;
        font-family: Consolas, monospace;
        padding: 20px;
        outline: 1px solid white;
        width: 650px;
      }
      .hilite {
        background-color: white;
        font-size: 18px;
        font-weight: bold;
        padding: 0px 4px 0px 4px;
        width: max-content;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 650px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 55px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 360px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
            
    </style>
    <!-- 1.END PAGE STYLE END -->

    <!-- 2.BEGIN ADD PAGE RESOURCES >> BEGIN -->
	<script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- 2.END ADD PAGE RESOURCES >> END -->
  </head>
  <body>
    <!-- 3.BEGIN HTML BODY >> BEGIN -->
  <div id="area">  
  <br>
	<h2>While, Break & Continue Examples (pg. 194-200)</h2>
    <div class="row">
      <div class="code">&lt;?php
        <br> &nbsp; // - - - general format of a <span class="hilite">while</span> and a <span class="hilite">do while</span> loop
        <br> &nbsp;
        <br> &nbsp; while ( <i>condition</i> ) {
        <br> &nbsp;    
        <br> &nbsp; &nbsp; <i>block of statements</i>
        <br> &nbsp;
        <br> &nbsp; }
        <br> &nbsp;
        <br> &nbsp; do {
        <br> &nbsp;    
        <br> &nbsp; &nbsp; <i>block of statements</i>
        <br> &nbsp;
        <br> &nbsp; } while ( <i>condition</i> );
        <br>?&gt;
      </div>
      <div class="middle">&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo "<i>condition</i> - a condition that must be true<br>\n";
        echo " &nbsp; to continue the loop: <br>\n";
        echo "<br>\n";
        echo " &nbsp; &nbsp; • for a <span class=\"hilite\">while</span> loop if the condition is <br>\n";
        echo " &nbsp; &nbsp; &nbsp; initally false, the <i>block of statements</i> <br>\n";
        echo " &nbsp; &nbsp; &nbsp; is never executed. <br>\n";
        echo "<br>\n";
        echo " &nbsp; &nbsp; • for a <span class=\"hilite\">do while</span> loop, the <i>block of</i> <br>\n";
        echo " &nbsp; &nbsp; &nbsp; <i>statements</i> is always executed <br>\n";
        echo " &nbsp; &nbsp; &nbsp; once before testing the condition <br>\n";
        echo " &nbsp; &nbsp; &nbsp; at the bottom of the loop. <br>\n";
        echo '<br><br><br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $pets = array("birds", "cats", "dogs", "horses");
        <br> &nbsp; $i = 0;
        <br> &nbsp; while ( $i < sizeof($pets) ) {
        <br> &nbsp; &nbsp; echo "$i. $pets[$i]&lt;br&gt;\n";
        <br> &nbsp; &nbsp; $i++;
        <br> &nbsp; }
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $pets = array("birds", "cats", "dogs", "horses");
        $i = 0;
        while ( $i < sizeof($pets) ) {
          echo "$i. $pets[$i]<br>\n";
          $i++;
        }
        echo '<br><br><br><br>';
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $tut = array("Windows", "SQLite", "PostgreSQL", "MySQL",);
        <br> &nbsp; 
        <br> &nbsp; $i = 0;
        <br> &nbsp; $c = "";
        <br> &nbsp; do {
        <br> &nbsp; &nbsp; if ( stristr($tut[$i], "sql") != "") {
        <br> &nbsp; &nbsp; &nbsp; echo "$c$tut[$i]";
        <br> &nbsp; &nbsp; &nbsp; $c = ", ";
        <br> &nbsp; &nbsp; }
        <br> &nbsp; &nbsp; $i++;
        <br> &nbsp; } while ( $i < sizeof($tut) );
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $tut = array("Windows", "SQLite", "PostgreSQL", "MySQL",);
        $i = 0;
        $c = "";
        do {
          if ( stristr($tut[$i], "sql") != "") {
            echo "$c$tut[$i]";
            $c = ", ";
          }
          $i++;
        } while ( $i < sizeof($tut) );
        echo '<br><br><br><br><br><br><br><br><br><br><br><br><br>'
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - use <span class="hilite">break;</span> to exit completely from a loop
        <br> &nbsp;
        <br> &nbsp; echo "Before loop&lt;br&gt;\n";
        <br> &nbsp; for( $i = 1; $i < 5; $i++ ) {
        <br> &nbsp; &nbsp; echo "  Loop $i before if &lt;br&gt;\n";
        <br> &nbsp; &nbsp; if ($i == 3) {
        <br> &nbsp; &nbsp; &nbsp; echo "  break;&lt;br&gt;\n";
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp; &nbsp; }
        <br> &nbsp; &nbsp; echo "  Loop $i after if&lt;br&gt;\n";
        <br> &nbsp; };
        <br> &nbsp; echo "After loop&lt;br&gt;\n";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo "Before loop<br>\n";
        for( $i = 1; $i < 5; $i++ ) {
          echo " &nbsp; Loop $i before <span class=\"hilite\">if</span><br>\n";
          if ($i == 3) {
            echo " &nbsp; <span class=\"hilite\">break;</span><br>\n";
            break;
          }
          echo " &nbsp; Loop $i after <span class=\"hilite\">if</span><br>\n";
        }
        echo "After loop<br>\n";
        echo '<br><br><br><br><br><br>';
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - use <span class="hilite">continue;</span> to skip to the next execution of a loop
        <br> &nbsp; 
        <br> &nbsp; echo "Before loop&lt;br&gt;\n";
        <br> &nbsp; for( $i = 1; $i < 5; $i++ ) {
        <br> &nbsp; &nbsp; echo "  Loop $i before if &lt;br&gt;\n";
        <br> &nbsp; &nbsp; if ($i == 3) {
        <br> &nbsp; &nbsp; &nbsp; echo "  continue;&lt;br&gt;\n";
        <br> &nbsp; &nbsp; &nbsp; continue;
        <br> &nbsp; &nbsp; }
        <br> &nbsp; &nbsp; echo "  Loop $i after if&lt;br&gt;\n";
        <br> &nbsp; };
        <br> &nbsp; echo "After loop&lt;br&gt;\n";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo "Before loop<br>\n";
        for( $i = 1; $i < 5; $i++ ) {
          echo " &nbsp; Loop $i before <span class=\"hilite\">if</span><br>\n";
          if ($i == 3) {
            echo " &nbsp; <span class=\"hilite\">continue;</span><br>\n";
            continue;
          }
          echo " &nbsp; Loop $i after <span class=\"hilite\">if</span><br>\n";
        }
        echo "After loop<br>\n";
        echo '<br><br><br><br>';
      ?>
      </div>
    </div>
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_More_Blocks.html">PHP More Blocks menu</a></td>
      </tr>
    </table>
  </div>

    <!-- 3.END HTML >> END -->

    <!-- 4.BEGIN JavaScript BODY >> BEGIN -->
    <script>

      var data = "data";
      	  
    </script>
    <!-- 4.END JavaScript BODY >> END -->
  </body>
</html>