<?php
$tut[] = "C Language";            
$tut[] = "C++";                   
$tut[] = "Bootstrap";             
$tut[] = "HTML5";                 
$tut[] = "HTML";                  
$tut[] = "CSS";                   
$tut[] = "CSS3";                  
$tut[] = "JAVA";                  
$tut[] = "JavaScript";            
$tut[] = "TypeScript";            
$tut[] = "jQuery";                
$tut[] = "PHP";                   
$tut[] = "IBM Db2";               
$tut[] = "MySQL";                 
$tut[] = "MariaDB";               
$tut[] = "SQL";                   
$tut[] = "AJAX";                  
$tut[] = "Python";                
$tut[] = "AngularJS";             
$tut[] = "Photoshop";             
$tut[] = "C#";                    
$tut[] = "ASP.NET";               
$tut[] = "SAP";                   
$tut[] = "Microsoft SQL Server";  
$tut[] = "ORACLE";                
$tut[] = "PostgreSQL";            
$tut[] = "SQLite";                
$tut[] = "Shopify";               
$tut[] = "Squarespace";           
$tut[] = "Weebly";                
$tut[] = "Wix";                   
$tut[] = "WordPress";             
$tut[] = "Android";               
$tut[] = "iOS";                   
$tut[] = "Linux";                 
$tut[] = "macOS";                 
$tut[] = "Windows";               
$tut[] = "PowerDirector";         
$tut[] = "ActionScript";          

// get the q parameter from URL
$q = $_REQUEST["q"];

$list = "";

// build a list of all titles from array if $q is not empty 
if ($q !== "") {
    foreach($tut as $title) {
        if (stristr($title, $q) != "") {
            if ($list === "") {
                $list = $title;
            } else {
                $list .= ", $title";
            }
        }
    }
}
// Output correct values 
echo $list === "" ? "no suggestion" : $list;
?>

