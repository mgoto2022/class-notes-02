<?php
  // Array with tutorials           // Array of category keywords
                                    //   (application, framework, language, dbms,
                                    //    operating system, website builder)
  $tut[] = "C Language";            $cat[] = "language";
  $tut[] = "C++";                   $cat[] = "language";
  $tut[] = "Bootstrap";             $cat[] = "framework";
  $tut[] = "HTML5";                 $cat[] = "language";
  $tut[] = "HTML";                  $cat[] = "language";
  $tut[] = "CSS";                   $cat[] = "language";
  $tut[] = "CSS3";                  $cat[] = "language";
  $tut[] = "JAVA";                  $cat[] = "language";
  $tut[] = "JavaScript";            $cat[] = "language";
  $tut[] = "TypeScript";            $cat[] = "language";
  $tut[] = "jQuery";                $cat[] = "framework";
  $tut[] = "PHP";                   $cat[] = "language";
  $tut[] = "IBM Db2";               $cat[] = "dbms";
  $tut[] = "MySQL";                 $cat[] = "dbms";
  $tut[] = "MariaDB";               $cat[] = "dbms MySQL";
  $tut[] = "SQL";                   $cat[] = "language";
  $tut[] = "AJAX";                  $cat[] = "framework";
  $tut[] = "Python";                $cat[] = "language";
  $tut[] = "AngularJS";             $cat[] = "framework";
  $tut[] = "Photoshop";             $cat[] = "application";
  $tut[] = "C#";                    $cat[] = "language";
  $tut[] = "ASP.NET";               $cat[] = "framework";
  $tut[] = "SAP";                   $cat[] = "application";
  $tut[] = "Microsoft SQL Server";  $cat[] = "dbms";
  $tut[] = "ORACLE";                $cat[] = "dbms";
  $tut[] = "PostgreSQL";            $cat[] = "dbms";
  $tut[] = "SQLite";                $cat[] = "dbms";
  $tut[] = "Shopify";               $cat[] = "website builder";
  $tut[] = "Squarespace";           $cat[] = "website builder";
  $tut[] = "Weebly";                $cat[] = "website builder";
  $tut[] = "Wix";                   $cat[] = "website builder";
  $tut[] = "WordPress";             $cat[] = "website builder";
  $tut[] = "Android";               $cat[] = "operating system";
  $tut[] = "iOS";                   $cat[] = "operating system";
  $tut[] = "Linux";                 $cat[] = "operating system";
  $tut[] = "macOS";                 $cat[] = "operating system";
  $tut[] = "Windows";               $cat[] = "operating system";
  $tut[] = "PowerDirector";         $cat[] = "application";
  $tut[] = "ActionScript";          $cat[] = "language";
                            
  // get the q parameter from URL
  $q = $_REQUEST["q"];

  /*  $c will be used to concatenate a comma and a space after
      the 1st tutorial title is found.
      $list will be used to contain the completed list of
      tutorial titles.
  */
  $c = "";
  $list = "";

  // build a list of all titles from array if $q is not empty 
  if ($q !== "") {

    /*  modify the following foreach statement so that each 
        index as well as each title is available for use within 
        the foreach loop. */
    #--- 1. Modify the following foreach line
    foreach($tut as $title) {

      /*  modify the following if statement so that
            if $q is found in $title  OR
            $q is found in the corresponding $cat value (e.g., $cat[$i]),
          the nest if statement is executed. */
      #--- 2. Modify the following if statement to use a complex condition
      if (stristr($title, $q) != "") {


        /*  modify the following assignment statements so that
            each found title will be concatenated to the $list
            variable and ", " will be inserted before each
            title (except for the 1st title). */
        #--- 3. Complete the following 2 lines 
        $list .= 
        $c= 
    }
    }
  }
  // Output correct values 
  echo $list === "" ? "no suggestion" : $list;
?>

