<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Switch Examples for Learning PHP and MySQL class</title>
    <!-- Introduction
    1. There are 4 sections total added to a vscode HTML 5 blank page. 
      - Each has BEGIN, END 
    2. These instructions are downloaded from https://github.com/mgoto2022/2nd-Level-Class-Notes
    -->
    <!-- 1.BEGIN PAGE CSS STYLE BEGIN -->
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .code {
        float: left;
        font-size: 20px;
        font-family: Consolas, monospace;
        padding: 20px;
        outline: 1px solid white;
        width: 620px;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 620px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 55px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 360px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
            
    </style>
    <!-- 1.END PAGE STYLE END -->

    <!-- 2.BEGIN ADD PAGE RESOURCES >> BEGIN -->
	<script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- 2.END ADD PAGE RESOURCES >> END -->
  </head>
  <body>
    <!-- 3.BEGIN HTML BODY >> BEGIN -->
  <div id="area">  
  <br>
	<h2>Switch Examples (pg. 190-191)</h2>
    <div class="row">
      <div class="code">&lt;?php
        <br> &nbsp; // - - - general format of a switch statement
        <br> &nbsp;
        <br> &nbsp; switch ( <i>$variable</i> ) {
        <br> &nbsp;    
        <br> &nbsp; &nbsp; case <i>value</i> :
        <br> &nbsp; &nbsp; &nbsp; <i>statement(s)</i>
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp;
        <br> &nbsp; &nbsp; case <i>value</i> :
        <br> &nbsp; &nbsp; &nbsp; <i>statement(s)</i>
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp;
        <br> &nbsp; &nbsp; &nbsp; . . .
        <br> &nbsp;
        <br> &nbsp; &nbsp; default :
        <br> &nbsp; &nbsp; &nbsp; <i>statement(s)</i>
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp;
        <br> &nbsp; }
        <br>?&gt;
      </div>
      <div class="middle">&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo "<br>\n";
        echo "<i>\$variable</i> is the variable whose value is <br>\n";
        echo " &nbsp; to be tested. <br>\n";
        echo '<br>';
        echo "<i>value</i> is one of many values to be found <br>\n";
        echo " &nbsp; --the value may be numeric, string or <br>\n";
        echo " &nbsp; boolean. <br>\n";
        echo '<br>';
        echo "<i>statement(s)</i> may be one or more lines <br>\n";
        echo " &nbsp; of executable statements. <br>\n";
        echo '<br>';
        echo "Use as many <b>case</b> sections as needed <br>\n";
        echo " &nbsp; --if the case <i>value</i> matches, all <br>\n";
        echo " &nbsp; statements are are executed until a <br>\n";
        echo " &nbsp; <b>break</b> statement is reached <br>\n";
        echo '<br>';
        echo "If no <b>case</b> value matches, an optional <br>\n";
        echo " &nbsp; <b>default</b> section may be used to <br>\n";
        echo " &nbsp; execute one or more statements <br>\n";
        echo '<br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        <br> &nbsp; $state = "TX";
        <br> &nbsp; switch ( $state ) {
        <br> &nbsp; &nbsp; case "ID" :
        <br> &nbsp; &nbsp; &nbsp; $incomeTax = 0.065;
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp; &nbsp; case "OR" :
        <br> &nbsp; &nbsp; &nbsp; $incomeTax = 0.099;
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp; &nbsp; default :
        <br> &nbsp; &nbsp; &nbsp; $incomeTax = 0.00;
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp; }
        <br> &nbsp; $taxRate = sprintf("%01.2f", ($incomeTax * 100));
        <br> &nbsp; echo "Income tax rate for $state is $taxRate%";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        $state = "TX";
        switch ( $state ) {
          case "ID" :
            $incomeTax = 0.065;
            break;
          case "OR" :
            $incomeTax = 0.099;
            break;
          default :
            $incomeTax = 0.00;
            break;
        }
        $taxRate = sprintf("%01.2f", ($incomeTax * 100));
        echo "Income tax rate for $state is $taxRate%";
        echo '<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $area = "713";
        <br> &nbsp; switch ( $area ) {
        <br> &nbsp; &nbsp; case "512" :
        <br> &nbsp; &nbsp; case "737" :
        <br> &nbsp; &nbsp; &nbsp; $city = "Austin";
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp; &nbsp; case "409" :
        <br> &nbsp; &nbsp; &nbsp; $city = "Galveston";
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp; &nbsp; case "713" :
        <br> &nbsp; &nbsp; case "281" :
        <br> &nbsp; &nbsp; case "832" :
        <br> &nbsp; &nbsp; &nbsp; $city = "Houston";
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp; &nbsp; default :
        <br> &nbsp; &nbsp; &nbsp; $city = "Anytown";
        <br> &nbsp; &nbsp; &nbsp; break;
        <br> &nbsp; }
        <br> &nbsp; echo "The $area area code is used in $city";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $area = "713";
        switch ( $area ) {
          case "512" :
          case "737" :
            $city = "Austin";
            break;
          case "409" :
            $city = "Galveston";
            break;
          case "713" :
          case "281" :
          case "832" :
            $city = "Houston";
            break;
          default :
            $city = "Anytown";
            break;
        }
        echo "The $area area code is used in $city";
        echo '<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>';
        echo '<br><br><br><br><br>';
      ?>  
      </div>
    </div>
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_More_Blocks.html">PHP More Blocks menu</a></td>
      </tr>
    </table>
  </div>

    <!-- 3.END HTML >> END -->

    <!-- 4.BEGIN JavaScript BODY >> BEGIN -->
    <script>

      var data = "data";
      	  
    </script>
    <!-- 4.END JavaScript BODY >> END -->
  </body>
</html>