<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Assignment 3 for Learning PHP and MySQL class</title>
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 650px;
      }
      .call {
        background-color: white;
        font-family: Courier, monospace;
        font-size: 20px;
        font-weight: bold;
        margin-left: 2px;
        margin-right: 2px;
        width: max-content;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 65px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 300px;
      }
      .array {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
      
    </style>
  </head>
  <body>
  <div id="area">  
  <br>
	<h2>Assignment 3 - More Blocks</h2>
    <div class="row">
      <div class="left">Use a <span class="call">switch</span> statement to set the sales tax rate ($tax) for the cities of
        <br> &nbsp; Austin (7.88%), Dallas (7%), and Houston (8.25%) with a default
        <br> &nbsp; of 6.25%.
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $city = "Houston";
        $tax = 0.00;
        #--- 1. Add a PHP switch statement to set city tax rates
        
        
          
          
          
          
          
          
          
          
          
          
          
        
        $pct = sprintf("%01.2f", ($tax));
        echo "Sales tax rate for $city is $pct%";
        echo '<br><br>';
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">Use a <span class="call">while</span> loop to search an array of names ($custs) for the name,
        <br> &nbsp; Smith using: &nbsp; $custs = array ('Huang', 'Smith', 'Jones');
      </div>
      <div class="middle">yields:<br>&nbsp;</div>
      <div class="right">
      <?php
        $custs = array ('Huang', 'Smith', 'Jones');
        #--- 2. Add a PHP while loop to search for Smith
        
        
        
        
        
        
        
        
        
        
        
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">Use a <span class="call">function</span> to display the PHP logo (php-logo.png) using a width
        <br> &nbsp; of 128 and a height of 64
        <br> &nbsp;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        #--- 3. Add a PHP function to display the PHP logo
        

        
        
        
        
        
        
      ?>
      </div>
    </div>
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_More_Blocks.html">PHP More Blocks menu</a></td>
        <td class="rtd"><a class="rtl" href="assignment_3.html">Assignment 3 - More Blocks</a></td>
      </tr>
    </table>
  </div>
  </body>
</html>