<!DOCTYPE html>
<html lang="en">
  <head>
    <title>PHP Get Row Example for Learning PHP and MySQL class</title>
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Fixedsys, monospace;
      }
      .left {
        float: left;
        font-size: 20px;
        outline: 1px solid white;
        padding: 20px;
        width: 680px;
      }
      .hilite {
        background-color: white;
        font-size: 18px;
        font-weight: bold;
        padding: 0px 4px 0px 4px;
        width: max-content;
      }
      .middle {
        float: left;
        font-size: 20px;
        height: 644px;
        outline: 1px solid white;
        padding: 20px;
        width: 65px;
      }
      .right {
        float: left;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 18px;
        height: 644px;
        outline: 1px solid white;
        padding: 20px;
        width: 480px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
      
    </style>
    <script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
  </head>
  <body>
  <div id="area">  
  <br>
  <h2>PHP Get Row example (pg. 224-225)</h2>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $host="localhost";
        <br> &nbsp; $user="root";
        <br> &nbsp; $password="";
        <br> &nbsp; $database = "PetCatalog";
        <br> &nbsp; $cxn = <i class="hilite">mysqli_connect</i>($host,$user,$password,$database)
        <br> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; or die ("Unable to connect to server");
        <br> &nbsp; $pettype = "cat";
        <br> &nbsp; $query = "SELECT * FROM Pet WHERE petType='$pettype'";
        <br> &nbsp; $result = <i class="hilite">mysqli_query</i>($cxn,$query)
        <br> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; or die ("Couldn't execute query.");
        <br> &nbsp; 
        <br> &nbsp; /* Display results in a table */
        <br> &nbsp; $pettype = ucfirst($pettype)."s";
        <br> &nbsp; echo "&lt;h4&gt;Displaying $pettype&lt;/h4&gt;\n";
        <br> &nbsp; echo "&lt;table cellspacing='15'&gt;\n";
        <br> &nbsp; echo "&lt;tr&gt;&lt;td colspan='3'&gt;&lt;hr /&gt;", "&lt;/td&gt;&lt;/tr&gt;\n";
        <br> &nbsp; while($row = <i class="hilite">mysqli_fetch_assoc</i>($result)) {
        <br> &nbsp; &nbsp; extract($row);
        <br> &nbsp; &nbsp; $f_price = number_format($price,2); 
        <br> &nbsp; &nbsp; echo "&lt;tr&gt;\n",
        <br> &nbsp; &nbsp; &nbsp; "&lt;td&gt;$petName&lt;/td&gt;\n", "&lt;td&gt;$petDescription&lt;/td&gt;\n",
        <br> &nbsp; &nbsp; &nbsp; "&lt;td style='text-align: right'&gt;\$$f_price&lt;/td&gt;\n",
        <br> &nbsp; &nbsp; &nbsp; "&lt;/tr&gt;\n";
        <br> &nbsp; &nbsp; echo "&lt;tr&gt;&lt;td colspan='3'&gt;&lt;hr /&gt;&lt;/td&gt;&lt;/tr&gt;\n";
        <br> &nbsp; }
        <br> &nbsp; echo "&lt;/table&gt;\n";
        <br>?&gt;
      </div>
      <div class="middle">yields:</div>
      <div class="right">
      <?php
        $host="localhost";
        $user="root";
        $password="";
        $database = "PetCatalog";
        $cxn = mysqli_connect($host,$user,$password,$database)
               or die ("Unable to connect to server");
        $pettype = "cat";  // Imagine cat was requested by a user
        $query = "SELECT * FROM Pet WHERE petType='$pettype'";
        $result = mysqli_query($cxn,$query)
                  or die ("Unable to execute query.");

        /* Display results in a table */
        $pettype = ucfirst($pettype)."s";
        echo "<h4>Displaying $pettype</h4>\n";
        echo "<table cellspacing='10'>\n";
        echo "<tr><td colspan='4'><hr /></td></tr>\n";
        while($row = mysqli_fetch_assoc($result)) {
          extract($row);
          $f_price = number_format($price,2);
          echo "<tr>\n
                <td>$petName</td>\n
                <td>$petDescription</td>\n
                <td style='text-align: right'>\$$f_price</td>\n
                </tr>\n";
          echo "<tr><td colspan='3'><hr /></td></tr>\n";
        }
        echo "</table>\n";
      ?>
      </div>
    </div>
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_Data_In_Out.html">PHP Data In & Out menu</a></td>
      </tr>
    </table>
  </div>
  </body>
</html>