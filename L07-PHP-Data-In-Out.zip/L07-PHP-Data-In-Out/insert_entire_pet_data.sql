USE `PetCatalog`;

--
-- Cats:  Insert data for Table: Pet
--
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (1,'Burmese','cat','small, light brown, cat',700.00,
  '/media/cat-burmese-light_brown.jpg');
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (2,'Persian','cat','docile, black, cat',1400.00,
  '/media/cat-persian-black.jpg');
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (3,'Scottish Fold','cat','playful, gray brown, cat',350.00,
  '/media/cat-scottish_fold-gray_brown.jpg');
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (4,'Siamese','cat','social, white w/ black tips, cat',700.00,
  '/media/cat-siamese-white_black.jpg');
  
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('cat','Cats are very sensitive to their interpersonal space.  They often do not have strict social hierarchies. They are also subtle in their display of friendly, or affiliative behaviors. Once aroused into threatening behaviors, cats can remain so for quite a long time.');
  
--
-- Insert data for Table: Color
--
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Burmese','light brown','/L03-DB-Design-and-SQL/media/cat-burmese-light_brown.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/cRBEL57B6ok" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Persian','black','/L03-DB-Design-and-SQL/media/cat-persian-black.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/QqZ7YkTdGIY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Scottish Fold','gray brown','/L03-DB-Design-and-SQL/media/cat-scottish_fold-gray_brown.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/mlNJMpBtNzo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Siamese','white black','/L03-DB-Design-and-SQL/media/cat-siamese-white_black.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/2LyVbxmMxqE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');

--
-- Horses:  Insert data for Table: Pet
--
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (5,"Clydesdale","horse","large powerful horse",4000.00,
  "/media/horse-clydesdale-brown_white_legs.jpg");
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (6,"Pegasus","horse","winged mare",80000.00,"/media/horse-pegasus-white.jpg");
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (7,"Unicorn","horse","white steed with spiral forehead horn",50000.00,"/media/horse-unicorn-white.jpg");
   
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('horse','Horses have oval-shaped hooves, long tails, short hair, long slender legs, muscular and deep torso build, long thick necks, and large elongated heads. The mane is a region of coarse hairs, which extends along the dorsal side of the neck in both domestic and wild species.');
   
--
-- Insert data for Table: Color
--
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Clydesdale','brown white','/L03-DB-Design-and-SQL/media/horse-clydesdale-brown_white_legs.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/_m7iKHUWq8M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Pegasus','white','/L03-DB-Design-and-SQL/media/horse-pegasus-white.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/sMGgc9nPtQU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Unicorn','white','/L03-DB-Design-and-SQL/media/horse-unicorn-white.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/uWkz0IggQjw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');

--
-- Dogs:  Insert data for Table: Pet (add VALUES to 2nd REPLACE)
--
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (8,'Beagle','dog','small scent hound dog',500.00,
 '/media/dog-beagle-white_brown_black.jpg');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */
  
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('dog','Dogs’ sense of smell is at least 40x better than ours.  Some have sich good noses that they can sniff our medical problems.  Some dogs are incredible swimmers.  Dogs pant to cool down instead of sweating.  Along with their noses, their hearing is super sensitive.');
  
--
-- Insert data for Table: Color (add VALUES to 2nd REPLACE)
--
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Beagle','white brown black','/L03-DB-Design-and-SQL/media/dog-beagle-white_brown_black.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/SSoV5gDGeN4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */

--
-- Birds:  Insert data for Table: Pet (add VALUES to 2nd REPLACE)
--
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (15,'Cockatoo','bird','small, playful, bird',3000.00,'/media/bird-cockatoo-white.jpg');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('bird','Pet birds are very affectionate and develop a close bond with their owners.  These birds become “possessive” and tend to bond to one person in particular so it is a good idea to keep the bird interacting with all the family members.  They are very playful and have entertaining personalities.');

--
-- Insert data for Table: Color  (add VALUES to 2nd REPLACE)
--
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Cockatoo','white','/L03-DB-Design-and-SQL/media/bird-cockatoo-white.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/qnkMobV-GvU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */
