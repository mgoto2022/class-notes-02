USE `PetCatalog`;

--
-- Delete reptile data from Table: PetType
--
DELETE FROM PetType WHERE petType = 'reptile';
