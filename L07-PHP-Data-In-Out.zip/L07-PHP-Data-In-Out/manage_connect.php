<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "userDirectory";
$tbname = 'crud';
$conn = mysqli_connect($servername, $username, $password);
if ( !$conn ) {
  die("Connection failed: " . mysqli_connect_error());
}
$res = mysqli_query($conn, "SHOW DATABASES LIKE '$dbname'");
if ( mysqli_fetch_row($res) ) {
  mysqli_select_db($conn, $dbname);  
} else {
  if ( !mysqli_query($conn, "CREATE DATABASE $dbname") ) {
    die("Error creating database \"$dbname\": ".mysql_error($conn));
  }
  if ( !mysqli_query($conn, "USE $dbname") ) {
    die("Error creating database \"$dbname\": ".mysql_error($conn));
  }
  if ( !mysqli_query($conn, "CREATE TABLE $tbname (
        id    int(10) unsigned NOT NULL AUTO_INCREMENT,
        name  varchar(64) NOT NULL,
        email varchar(128) NOT NULL,
        phone varchar(24) NULL DEFAULT NULL,  
        city  varchar(64) NULL DEFAULT NULL,
        PRIMARY KEY (id))") ) {
    die("Error creating table \"$tbname\": ".mysql_error($conn));
  }
  if ( !mysqli_query($conn, "INSERT INTO $tbname (name, email, phone, city)
        VALUES
        ('Jose Lopez','jlopez@att.net','(210)-201-2181','San Antonio, TX'),
        ('Lily Sato','lily.sato@gmail.com','(713)-496-1729','Houston, TX'),
        ('Tyrone Smith','tyrone-smith@aol.com','(214)-207-6318','Dallas, TX'),
        ('Wei Li','wei_li@yahoo.com','(512)-202-0498','Austin, TX')") ) {
    die("Error creating table \"crud\": ".mysql_error($conn));
  }
}
?>