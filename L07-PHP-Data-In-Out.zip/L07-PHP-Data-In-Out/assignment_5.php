<?php
  // connect to Tutorials database
  include 'assignment_5-connect.php';

  // get the q parameter from URL
  $q = $_REQUEST["q"];
  $c = "";
  $list = "";

  // Search database if $q is not empty 
  if ($q !== "") {
    
    #--- 1. Escape User Input to avoid SQL Injection & send query
    
    
    

    #--- 2. Read each row of database


      #--- 3. Search each row of database



    #--- 4. End read-row loop

  }
  // Output correct values 
  echo $list === "" ? "no suggestion" : $list;

  #--- 5. Close MySQL connection

?>
