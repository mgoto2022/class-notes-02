<?php
  $host = "localhost";
  $user = "root";
  $pswd = "";
  $dbname = "PetCatalog";

  // Connect to MySQL and select Database
  $cxn = mysqli_connect($host,$user,$pswd,$dbname)
         or die ("<p>Unable to connect to server</p>");

  // Retrieve data from Query String
  $breed = $_GET['breed'];
  $price = $_GET['price'];
  $type = $_GET['type'];
  
  // Escape User Input to help prevent SQL Injection
  $breed = mysqli_real_escape_string($cxn,$breed);
  $price = mysqli_real_escape_string($cxn,$price);
  $type = mysqli_real_escape_string($cxn,$type);
  if ($type == "") {
    $type = "cat";
  }

  // Build and send query
  $query = "SELECT * FROM pet WHERE petType = '$type'";
  if ($breed != "") {
    $query .= " AND petName = '$breed'";
  }
  if (is_numeric($price)) {
    $query .= " AND price <= $price";
  }
  $result = mysqli_query($cxn,$query)
            or die(mysqli_error($cxn));

  // Display results in a table
  $type = ucfirst($type)."s";
  echo "<h4>Matching $type</h4>\n";
  echo "<table cellspacing='10'>\n";
  echo "<tr><td colspan='4'><hr /></td></tr>\n";
  while($row = mysqli_fetch_assoc($result)) {
    extract($row);
    $f_price = number_format($price,2);
    echo "<tr>",
      "<td>$petName</td>",
      "<td>$petDescription</td>",
      "<td style='text-align: right'>\$$f_price</td>",
      "</tr>\n";
    echo "<tr><td colspan='3'><hr /></td></tr>\n";
  }
  echo "</table>\n";
?>

