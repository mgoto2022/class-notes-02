<?php
include 'manage_connect.php';
if(count($_POST)>0){
	/*
	- Obtain the type of request */
	$req=$_POST['type'];
	/*
    <!-- #1 -->
	- For type=1, add a new user using INSERT ... VALUES */
	if ($req==1){
		$name=$_POST['name'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$city=$_POST['city'];
		$sql = "INSERT INTO $tbname ( `name`, `email`,`phone`,`city`) 
		VALUES ('$name','$email','$phone','$city')";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	/*
    <!-- #2 -->
	- For type=2, update a user using UPDATE ... SET */
} elseif ($req==2) {
		$id=$_POST['id'];
		$name=$_POST['name'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$city=$_POST['city'];
		$sql = "UPDATE $tbname SET `name`='$name',`email`='$email',`phone`='$phone',`city`='$city' WHERE id=$id";
		if (mysqli_query($conn, $sql)) {
			echo json_encode(array("statusCode"=>200));
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	/*
    <!-- #3 -->
	- For type=3, delete a user using DELETE with a single id */
} elseif ($req==3) {
		$id=$_POST['id'];
		$sql = "DELETE FROM $tbname WHERE id=$id ";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	/*
    <!-- #4 -->
	- For type=4, delete user(s) using DELETE with a list of ids */
} elseif ($req==4) {
		$id=$_POST['id'];
		$sql = "DELETE FROM $tbname WHERE id in ($id)";
		if (mysqli_query($conn, $sql)) {
			echo $id;
		} 
		else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		mysqli_close($conn);
	/*
	- Otherwise, return an error with the request type */
} else {
		$msg = "  Invalid request type";
		echo json_encode(array("statusCode"=>201,"Error"=>$msg,"req"=>$req)); 
	}
}

?>