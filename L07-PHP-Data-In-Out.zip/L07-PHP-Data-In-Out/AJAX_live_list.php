<?php
  $host = "localhost";
  $user = "root";
  $pswd = "";
  $dbname = "PetCatalog";

  // Connect to MySQL and select Database
  $cxn = mysqli_connect($host,$user,$pswd,$dbname)
         or die ("<p>Unable to connect to server</p>");

  // Build and send query
  $query = "SELECT petType FROM pettype WHERE petType != ''";
  $result = mysqli_query($cxn,$query) or die(mysqli_error($cxn));

  // Convert results into <option ... > ... </option> rows
  while($row = mysqli_fetch_assoc($result)) {
    extract($row);
    // If the type is 'cat', add 'selected' attribute
    if ( $petType == 'cat' ) {
      $selected = " selected";
    } else {
      $selected = "";
    }
    $type = ucfirst($petType);
    echo "<option value=\"", $petType, "\"",
  	  $selected, ">", $type, "</option>\n";
  }
?>

