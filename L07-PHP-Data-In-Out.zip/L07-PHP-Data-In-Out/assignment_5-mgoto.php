<?php
  // connect to Tutorials database
  include 'assignment_5-connect.php';

  // get the q parameter from URL
  $q = $_REQUEST["q"];
  $c = "";
  $list = "";

  // Search database if $q is not empty 
  if ($q !== "") {

    #--- 1. Escape User Input to avoid SQL Injection & send query
	$q = mysqli_real_escape_string($conn,$q);
    $sql = "SELECT * FROM Titles WHERE tut LIKE '%$q%' OR cat LIKE '%$q%'";
    $result = mysqli_query($conn,$sql);

    #--- 2. Read each row of database
    while ($row = mysqli_fetch_assoc($result)) {

      #--- 3. Append each tutorial title to the response
      $list .= $c.$row["tut"];
      $c= ", ";

    #--- 4. End read-row loop
    }
  }
  // Output correct values 
  echo $list === "" ? "no suggestion" : $list;
  
  #--- 5. Close MySQL connection
  mysqli_close($conn);
?>