
--
-- Drop & Create Database: `userDirectory`
--
DROP DATABASE IF EXISTS `userDirectory`;

CREATE DATABASE `userDirectory`;
USE  `userDirectory`;

--
-- Create Table: items
--
CREATE TABLE `crud` (
  `id`        int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name`      varchar(64) NOT NULL,
  `email`     varchar(128) NOT NULL,
  `phone`     varchar(24) NULL DEFAULT NULL,
  `city`      varchar(64) NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
);

--
-- Insert data for Table: `items`
--
INSERT INTO `crud` (`name`, `email`,`phone`,`city`)
VALUES
  ('Jose Lopez','jlopez@att.net','(210)-201-2181','San Antonio, TX'),
  ('Lily Sato','lily.sato@gmail.com','(713)-496-1729','Houston, TX'),
  ('Tyrone Smith','tyrone-smith@aol.com','(214)-207-6318','Dallas, TX'),
  ('Wei Li','wei_li@yahoo.com','(512)-202-0498','Austin, TX');