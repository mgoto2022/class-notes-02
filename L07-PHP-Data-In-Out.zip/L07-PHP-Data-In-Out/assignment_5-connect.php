<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Tutorials";
$tbname = 'Titles';
$conn = mysqli_connect($servername, $username, $password);
if ( !$conn ) {
  die("Connection failed: " . mysqli_connect_error());
}
$res = mysqli_query($conn, "SHOW DATABASES LIKE '$dbname'");
if ( mysqli_fetch_row($res) ) {
  mysqli_select_db($conn, $dbname);  
} else {
  if ( !mysqli_query($conn, "CREATE DATABASE $dbname") ) {
    die("Error creating database \"$dbname\": ".mysql_error($conn));
  }
  if ( !mysqli_query($conn, "USE $dbname") ) {
    die("Error creating database \"$dbname\": ".mysql_error($conn));
  }
  if ( !mysqli_query($conn, "CREATE TABLE $tbname (
        id    SERIAL,
        tut   varchar(64) NOT NULL,
        cat   varchar(64) NOT NULL,
        PRIMARY KEY (id))") ) {
    die("Error creating table \"$tbname\": ".mysql_error($conn));
  }
  if ( !mysqli_query($conn, "INSERT INTO $tbname (tut, cat) VALUES
        ('C Language',            'language'),
        ('Bootstrap',             'framework'),
        ('HTML5',                 'language'),
        ('HTML',                  'language'),
        ('CSS',                   'language'),
        ('CSS3',                  'language'),
        ('JAVA',                  'language'),
        ('JavaScript',            'language'),
        ('TypeScript',            'language'),
        ('jQuery',                'framework'),
        ('PHP',                   'language'),
        ('IBM Db2',               'dbms'),
        ('MySQL',                 'dbms'),
        ('MariaDB',               'dbms MySQL'),
        ('SQL',                   'language'),
        ('AJAX',                  'framework'),
        ('Python',                'language'),
        ('AngularJS',             'framework'),
        ('Photoshop',             'application'),
        ('ASP.NET',               'framework'),
        ('SAP',                   'application'),
        ('Microsoft SQL Server',  'dbms'),
        ('ORACLE',                'dbms'),
        ('PostgreSQL',            'dbms'),
        ('SQLite',                'dbms'),
        ('Shopify',               'website builder'),
        ('Squarespace',           'website builder'),
        ('Weebly',                'website builder'),
        ('Wix',                   'website builder'),
        ('WordPress',             'website builder'),
        ('Android',               'operating system'),
        ('iOS',                   'operating system'),
        ('Linux',                 'operating system'),
        ('macOS',                 'operating system'),
        ('Windows',               'operating system'),
        ('PowerDirector',         'application'),
        ('ActionScript',          'language')") ) {
    die("Error creating table \"crud\": ".mysql_error($conn));
  }
}
?>