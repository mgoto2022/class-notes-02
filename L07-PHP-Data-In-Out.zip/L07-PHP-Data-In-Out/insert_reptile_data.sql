USE `PetCatalog`;

--
-- Insert reptile data into Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('reptile','Reptiles include snakes, lizards, turtles and tortoises and most are cold-blooded. All reptiles are vertebrates (have backbones) and have four limbs or are descended from four-limbed animals. Also, reptiles breathe with the aid of lungs.');
