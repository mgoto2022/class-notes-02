
--
-- Drop Database: `HouseholdDirectory`
--
DROP DATABASE IF EXISTS `HouseholdDirectory`;

--
-- Create Database: `HouseholdDirectory`;
--
CREATE DATABASE `HouseholdDirectory` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

--
-- Create Table: `Homes`
--
CREATE TABLE `HouseholdDirectory`.`Homes`
  (`h_id` SERIAL
  ,`homeAddress` CHAR(64) NOT NULL
  ,`phoneNumber` CHAR(14) NOT NULL
) DEFAULT CHARSET=utf8mb4; 

--
-- Insert data for Table: `Homes`
--
INSERT INTO `HouseholdDirectory`.`Homes` ( `homeAddress`, `phoneNumber`)
 VALUES ("1234 Cherry Lane", "(123)-555-1234");
INSERT INTO `HouseholdDirectory`.`Homes` ( `homeAddress`, `phoneNumber`)
 VALUES ("5678 Cherry Lane", "(123)-555-5678");
INSERT INTO `HouseholdDirectory`.`Homes` ( `homeAddress`, `phoneNumber`)
 VALUES ("1234 Oakwood Lane", "(456)-555-1234");
INSERT INTO `HouseholdDirectory`.`Homes` ( `homeAddress`, `phoneNumber`)
 VALUES ("5678 Oakwood Lane", "(456)-555-5678");

--
-- Create Table: `People`
--
CREATE TABLE `HouseholdDirectory`.`People`
  (`p_id` SERIAL
  ,`firstName` VARCHAR(64) NOT NULL
  ,`lastName` VARCHAR(64) NOT NULL
  ,`middleName` VARCHAR(64)
  ,`age` DECIMAL(3) DEFAULT 0
  ,`favoriteCereal` VARCHAR(64)
) DEFAULT CHARSET=utf8mb4; 

--
-- Insert data for Table: `People`
--
INSERT INTO `HouseholdDirectory`.`People` ( `firstName`, `lastName`, `middleName`, `age`, `favoriteCereal`)
 VALUES ("John", "Doe", "", 35, "Corn Flakes");
INSERT INTO `HouseholdDirectory`.`People` ( `firstName`, `lastName`, `middleName`, `age`, `favoriteCereal`)
 VALUES ("Jane", "Doe", "", 34, "Apple Jacks");
INSERT INTO `HouseholdDirectory`.`People` ( `firstName`, `lastName`, `middleName`, `age`, `favoriteCereal`)
 VALUES ("Jimmy", "Doe", "", 6, "Cap'n Crunch");
INSERT INTO `HouseholdDirectory`.`People` ( `firstName`, `lastName`, `middleName`, `age`, `favoriteCereal`)
 VALUES ("John", "Smith", "", 37, "Raisin Bran");
INSERT INTO `HouseholdDirectory`.`People` ( `firstName`, `lastName`, `middleName`, `age`, `favoriteCereal`)
 VALUES ("Jane", "Smith", "", 36, "Special K");
INSERT INTO `HouseholdDirectory`.`People` ( `firstName`, `lastName`, `middleName`, `age`, `favoriteCereal`)
 VALUES ("Jenny", "Smith", "", 7, "Fruity Pebbles");
