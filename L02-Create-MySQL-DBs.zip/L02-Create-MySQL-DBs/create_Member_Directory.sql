
--
-- Drop Database: `MemberDirectory`
--
DROP DATABASE IF EXISTS `MemberDirectory`;

--
-- Create Database: `MemberDirectory`;
--
CREATE DATABASE `MemberDirectory` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

--
-- Create Table: `Member`
--
CREATE TABLE `MemberDirectory`.`Member`
  (`loginName` VARCHAR(80) 
  ,`password` CHAR(255) NOT NULL DEFAULT("password")
  ,`createDate` DATE NOT NULL DEFAULT NOW()
  ,`lastName` VARCHAR(20) NOT NULL
  ,`firstName` VARCHAR(40) NOT NULL
  ,`street` VARCHAR(50) NOT NULL
  ,`city` VARCHAR(50) NOT NULL
  ,`state` CHAR(2) NOT NULL
  ,`zip` CHAR(10) NOT NULL
  ,`email` VARCHAR(50) NOT NULL
  ,`phone` VARCHAR(15) NOT NULL
  ,`fax` VARCHAR(15) DEFAULT("")
  ,PRIMARY KEY (`loginName`)
) DEFAULT CHARSET=utf8mb4; 

--
-- Insert data for Table: `Member`
--
INSERT INTO `MemberDirectory`.`Member`
 ( `loginName`,`lastName`,`firstName`,`street`,`city`,`state`,`zip`,`email`,`phone`)
 VALUES ("John_Doe@acme.com","Doe","John","1234 Cherry Lane","Green Hills","MT"
   ,"20252-2047","John_Doe@acme.com","(123)-555-1234");
INSERT INTO `MemberDirectory`.`Member`
 ( `loginName`,`lastName`,`firstName`,`street`,`city`,`state`,`zip`,`email`,`phone`)
 VALUES ("John_Smith@acme.com","Smith","John","5678 Cherry Lane","Haddonfield","IL"
   ,"62279-7924","John_Smith@acme.com","(123)-555-5678");
INSERT INTO `MemberDirectory`.`Member`
 ( `loginName`,`lastName`,`firstName`,`street`,`city`,`state`,`zip`,`email`,`phone`)
 VALUES ("Richard_Row@acme.com","Roe","Richard","1234 Oakwood Lane","Derry","ME"
   ,"04741-7924","Richard_Row@acme.com","(456)-555-1234");
 
--
-- Create Table: `Login`
--
CREATE TABLE `MemberDirectory`.`Login`
  (`loginName` VARCHAR(80) 
  ,`loginTime` DATETIME NOT NULL DEFAULT NOW()
  ,PRIMARY KEY (`loginName`)
) DEFAULT CHARSET=utf8mb4; 

--
-- Insert data for Table: `Login`
--
INSERT INTO `MemberDirectory`.`Login` ( `loginName`)
 VALUES ("John_Smith@acme.com");
INSERT INTO `MemberDirectory`.`Login` ( `loginName`)
 VALUES ("Richard_Row@acme.com");
