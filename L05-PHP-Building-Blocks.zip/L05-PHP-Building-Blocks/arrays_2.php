<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Array Examples (2 of 2) for Learning PHP and MySQL class</title>
    <!-- Introduction
    1. There are 4 sections total added to a vscode HTML 5 blank page. 
      - Each has BEGIN, END 
    2. These instructions are downloaded from https://github.com/mgoto2022/2nd-Level-Class-Notes
    -->
    <!-- 1.BEGIN PAGE CSS STYLE BEGIN -->
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 620px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 55px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 300px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
            
    </style>
    <!-- 1.END PAGE STYLE END -->

    <!-- 2.BEGIN ADD PAGE RESOURCES >> BEGIN -->
	<script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- 2.END ADD PAGE RESOURCES >> END -->
  </head>
  <body>
    <!-- 3.BEGIN HTML BODY >> BEGIN -->
  <div id="area">  
  <br>
	<h2>Array Examples (2 of 2) (pg. 178-186)</h2>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - access an individual value from an array
        <br> &nbsp; $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        <br> &nbsp; $capitalTX = $capitals['TX'];
        <br> &nbsp; echo '$capitalTX = ', $capitalTX, "&lt;br&gt;\n";
        <br> &nbsp;
        <br> &nbsp; // - - - retrieve a list of values from an array
        <br> &nbsp; $pets = array("dragon","unicorn","tiger");
        <br> &nbsp; list($_1st,$_2nd) = $pets;
        <br> &nbsp; echo '$_1st = ', $_1st, '; $_2nd = ', $_2nd, "&lt;br&gt;\n";
        <br> &nbsp;
        <br> &nbsp; // - - - extracting all values from an array
        <br> &nbsp; $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        <br> &nbsp; extract($capitals);
        <br> &nbsp; echo "ID = $ID; TX = $TX; OR = $OR, "&lt;br&gt;\n"";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo "<br>\n";
        $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        $capitalTX = $capitals['TX'];
        echo '$capitalTX = ', $capitalTX, "<br>\n";
        echo '<br><br><br><br>';
        $pets = array("dragon","unicorn","tiger");
        list($_1st,$_2nd) = $pets;
        echo '$_1st = ', $_1st, '; $_2nd = ', $_2nd, "<br>\n";
        echo '<br><br><br><br>';
        $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        extract($capitals);
        echo "ID = $ID; TX = $TX; OR = $OR", "<br>\n";
        echo '<br><br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - walk through an array using a pointer (see pg. 180-181)
        <br> &nbsp; $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        <br> &nbsp; $value = current($capitals);
        <br> &nbsp; echo "$value &lt;br&gt;\n";
        <br> &nbsp; $value = next($capitals);
        <br> &nbsp; echo "$value &lt;br&gt;\n";
        <br> &nbsp; $value = next($capitals);
        <br> &nbsp; echo "$value &lt;br&gt;\n";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        $value = current($capitals); 
        echo "$value <br>\n";
        $value = next($capitals);
        echo "$value <br>\n";
        $value = next($capitals);
        echo "$value <br>\n";
        echo '<br><br><br><br><br><br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - walk through an array using foreach (see pg. 181-182)
        <br> &nbsp; $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        <br> &nbsp; 
        <br> &nbsp; foreach($capitals as $state => $city) {
        <br> &nbsp; &nbsp; echo "$city, $state &lt;br&gt;\n";
        <br> &nbsp; }
        <br> &nbsp; foreach($capitals as $city) {
        <br> &nbsp; &nbsp; echo "$city &lt;br&gt;\n";
        <br> &nbsp; }
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        $value = current($capitals);
        foreach($capitals as $state => $city) {
          echo "$city, $state <br>\n";
        }
        echo '<br>';
        foreach($capitals as $city) {
          echo "$city <br>\n";
        }
        echo '<br><br><br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - multi-dimensional array example (see pg. 183-186)
        <br> &nbsp; $prices['clothing']['shirt'] = 20.00;
        <br> &nbsp; $prices['clothing']['pants'] = 22.50;
        <br> &nbsp; $prices['linens']['blanket'] = 25.00;
        <br> &nbsp; $prices['linens']['bedspread'] = 50.00;
        <br> &nbsp; $prices['furniture']['lamp'] = 44.00;
        <br> &nbsp; $prices['furniture']['rug'] = 75.00;
        <br> &nbsp; echo "Shirt price is \${$prices['clothing']['shirt']} &lt;br&gt;\n";
        <br> &nbsp; echo "&lt;table> border = '1'&gt; \n";
        <br> &nbsp; foreach( $prices as $category ) {
        <br> &nbsp; &nbsp; foreach( $category as $product => $price ) {
        <br> &nbsp; &nbsp; &nbsp; $dollars = sprintf("%01.2f", $price);
        <br> &nbsp; &nbsp; &nbsp; echo "&lt;tr&gt; &lt;td&gt; $product: &lt;/td&gt; &lt;td&gt; \$$dollars &lt;/td&gt; &lt;/tf&gt; \n";
        <br> &nbsp; &nbsp; }
        <br> &nbsp; }
        <br> &nbsp; echo "&lt;/table&gt; \n\n";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $prices['clothing']['shirt'] = 20.00;
        $prices['clothing']['pants'] = 22.50;
        $prices['linens']['blanket'] = 25.00;
        $prices['linens']['bedspread'] = 50.00;
        $prices['furniture']['lamp'] = 44.00;
        $prices['furniture']['rug'] = 75.00;
        echo "\n";
        echo "Shirt price is \${$prices['clothing']['shirt']} <br>\n";
        echo "<br>\n";
        echo "<table border='1' cellspacing='3'> \n";
        foreach( $prices as $category ) {
          foreach( $category as $product => $price ) {
            $dollars = sprintf("%01.2f", $price);
            echo "<tr> <td> $product: </td> <td> \$$dollars </td> </tr> \n";
          }  
        }
        echo "</table> \n\n";
        echo '<br><br><br><br><br><br><br><br>';
      ?>  
      </div>
    </div>
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_Building_Blocks.html">PHP Building Blocks menu</a></td>
      </tr>
    </table>
  </div>

    <!-- 3.END HTML >> END -->

    <!-- 4.BEGIN JavaScript BODY >> BEGIN -->
    <script>

      var data = "data";
      	  
    </script>
    <!-- 4.END JavaScript BODY >> END -->
  </body>
</html>