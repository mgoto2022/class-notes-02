<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Array Examples (1 of 2) for Learning PHP and MySQL class</title>
    <!-- Introduction
    1. There are 4 sections total added to a vscode HTML 5 blank page. 
      - Each has BEGIN, END 
    2. These instructions are downloaded from https://github.com/mgoto2022/2nd-Level-Class-Notes
    -->
    <!-- 1.BEGIN PAGE CSS STYLE BEGIN -->
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 620px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 55px;
      }
      .right {
        float: left;
        font-size: 18px;
        padding: 20px;
        outline: 1px solid white;
        width: 300px;
      }
      .right-single {
        float: left;
        font-size: 18px;
        padding: 20px 20px 14px 20px;
        outline: 1px solid white;
        width: 300px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
            
    </style>
    <!-- 1.END PAGE STYLE END -->

    <!-- 2.BEGIN ADD PAGE RESOURCES >> BEGIN -->
	<script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- 2.END ADD PAGE RESOURCES >> END -->
  </head>
  <body>
    <!-- 3.BEGIN HTML BODY >> BEGIN -->
  <div id="area">  
  <br>
	<h2>Array Examples (1 of 2) (pg. 173-178)</h2>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - an array with 3 values, numbered 0, 1 & 2
        <br> &nbsp; $pets[0] = "dragon";
        <br> &nbsp; $pets[1] = "unicorn";
        <br> &nbsp; $pets[2] = "tiger";
        <br> &nbsp; // - - - print the pets array
        <br> &nbsp; print_r($pets);
        <br>&nbsp;
        <br> &nbsp; // - - - shortcut array assignment
        <br> &nbsp; $pets = array("dragon","unicorn","tiger");
        <br> &nbsp; // - - - print the pets array, again
        <br> &nbsp; print_r($pets);
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $pets[0] = "dragon";
        $pets[1] = "unicorn";
        $pets[2] = "tiger";
        echo "<pre>";
        print_r($pets);
        $pets = array("dragon","unicorn","tiger");
        print_r($pets);
        echo "</pre>";
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - an array with 3 key/value pairs
        <br> &nbsp; $capitals['ID'] = "Boise";
        <br> &nbsp; $capitals['TX'] = "Austin";
        <br> &nbsp; $capitals['OR'] = "Salem";
        <br> &nbsp; // - - - print the capitals array
        <br> &nbsp; print_r($capitals);
        <br>&nbsp;
        <br> &nbsp; // - - - shortcut array assignment
        <br> &nbsp; $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        <br> &nbsp; // - - - print the capitals array, again
        <br> &nbsp; print_r($capitals);
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $capitals['ID'] = "Boise";
        $capitals['TX'] = "Austin";
        $capitals['OR'] = "Salem";
        echo "<pre>";
        print_r($capitals);
        $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        print_r($capitals);
        echo "</pre>";
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - removing "parrot" from $pets array
        <br> &nbsp; $pets = array("dragon","unicorn","parrot","tiger");
        <br> &nbsp; unset($pets[2]);
        <br> &nbsp; print_r($pets);
        <br>?&gt;
        <br>&nbsp;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right-single">
      <?php
        $pets = array("dragon","unicorn","parrot","tiger");
        unset($pets[2]);
        echo "<pre>";
        print_r($pets);
        echo "</pre>";
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - sorting numbered array values
        <br> &nbsp; $pets = array("dragon","unicorn","tiger");
        <br> &nbsp; sort($pets);
        <br> &nbsp; print_r($pets);
        <br>?&gt;
        <br>&nbsp;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right-single">
      <?php
        $pets = array("dragon","unicorn","tiger");
        sort($pets);
        echo "<pre>";
        print_r($pets);
        echo "</pre>";
      ?>
      </div>
    </div>  
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - sorting keyed array values
        <br> &nbsp; $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        <br> &nbsp; asort($capitals);
        <br> &nbsp; print_r($capitals);
        <br>?&gt;
        <br>&nbsp;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right-single">
      <?php
        $capitals = array("ID"=>"Boise","TX"=>"Austin","OR"=>"Salem");
        asort($capitals);
        echo "<pre>";
        print_r($capitals);
        echo "</pre>";
      ?>
      </div>
    </div>  
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_Building_Blocks.html">PHP Building Blocks menu</a></td>
      </tr>
    </table>
  </div>

    <!-- 3.END HTML >> END -->

    <!-- 4.BEGIN JavaScript BODY >> BEGIN -->
    <script>

      var data = "data";
      	  
    </script>
    <!-- 4.END JavaScript BODY >> END -->
  </body>
</html>