<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>If Examples for Learning PHP and MySQL class</title>
    <!-- Introduction
    1. There are 4 sections total added to a vscode HTML 5 blank page. 
      - Each has BEGIN, END 
    2. These instructions are downloaded from https://github.com/mgoto2022/2nd-Level-Class-Notes
    -->
    <!-- 1.BEGIN PAGE CSS STYLE BEGIN -->
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .code {
        float: left;
        font-size: 20px;
        font-family: Consolas, monospace;
        padding: 20px;
        outline: 1px solid white;
        width: 650px;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 650px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 55px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 360px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
            
    </style>
    <!-- 1.END PAGE STYLE END -->

    <!-- 2.BEGIN ADD PAGE RESOURCES >> BEGIN -->
	<script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- 2.END ADD PAGE RESOURCES >> END -->
  </head>
  <body>
    <!-- 3.BEGIN HTML BODY >> BEGIN -->
  <div id="area">  
  <br>
	<h2>If Examples (pg. 187-190)</h2>
    <div class="row">
      <div class="code">&lt;?php
        <br> &nbsp; // - - - general format of an if statement
        <br> &nbsp;
        <br> &nbsp; if ( <i>condition</i> ) {
        <br> &nbsp;    
        <br> &nbsp; &nbsp; <i>statement(s)</i>
        <br> &nbsp;
        <br> &nbsp; } elseif ( <i>condition</i> ) {
        <br> &nbsp;
        <br> &nbsp; &nbsp; <i>statement(s)</i>
        <br> &nbsp;
        <br> &nbsp; } else {
        <br> &nbsp;    
        <br> &nbsp; &nbsp; <i>statement(s)</i>
        <br> &nbsp;
        <br> &nbsp; }
        <br>?&gt;
      </div>
      <div class="middle">&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo "<br>\n";
        echo "<i>condition</i> may be a simple comparison, <br>\n";
        echo " &nbsp; multiple comparisons with <b>&&</b> (and) <br>\n";
        echo " &nbsp; or <b>||</b> (or) or any expression that <br>\n";
        echo " &nbsp; returns true or false. <br>\n";
        echo '<br>';
        echo "<i>statement(s)</i> may be one or many lines <br>\n";
        echo " &nbsp; of executable statements. <br>\n";
        echo '<br><br><br><br><br><br><br><br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $country = "U.S.A.";
        <br> &nbsp; if ( $country == "China" ) {
        <br> &nbsp; &nbsp; $version = "Chinese";
        <br> &nbsp; &nbsp; $message = "請參閱我們的中文目錄";
        <br> &nbsp; } elseif ( $country == "Japan" ) {
        <br> &nbsp; &nbsp; $version = "Japanese";
        <br> &nbsp; &nbsp; $message = "Nihongo no katarogu o goran kudasai";
        <br> &nbsp; } else {
        <br> &nbsp; &nbsp; $version = "English";
        <br> &nbsp; &nbsp; $message = "Please see our catalog in English";
        <br> &nbsp; }
        <br> &nbsp; echo "$message &lt;br&gt;\n";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo "<br>\n";
        $country = "U.S.A.";
        if ( $country == "China" ) {
            $version = "Chinese";
            $message = "請參閱我們的中文目錄";
        } elseif ( $country == "Japan" ) {
            $version = "Japanese";
            $message = "Nihongo no katarogu o goran kudasai";
        } else {
            $version = "English";
            $message = "Please see our catalog in English";
        } 
        echo "$message <br>\n";
        echo '<br><br><br><br><br><br><br><br><br><br><br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - nested if statements
        <br> &nbsp; $s = "search";
        <br> &nbsp; $title = "Linear Search";
        <br> &nbsp; if ( stristr($title, $s) != "" ) {
        <br> &nbsp; &nbsp; if ( stristr($title, "linear") != "") {
        <br> &nbsp; &nbsp; &nbsp; $quality = "slow";
        <br> &nbsp; &nbsp; } else {
        <br> &nbsp; &nbsp; &nbsp; $quality = "good";
        <br> &nbsp; &nbsp; }
        <br> &nbsp; &nbsp; echo "$title is a $quality search &lt;br&gt;\n";
        <br> &nbsp; } else {
        <br> &nbsp; &nbsp; echo "$s was not found &lt;br&gt;\n";
        <br> &nbsp; }
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo "<br>\n";
        $s = "search";
        $title = "Linear Search";
        if ( stristr($title, $s) != "" ) {
            if ( stristr($title, "linear") != "") {
                $quality = "slow";
            } else {
                $quality = "good";
            }
            echo "$title is a $quality search <br>\n";
        } else {
            echo "$s was not found <br>\n";
        }
        echo '<br><br><br><br><br><br><br><br><br><br><br><br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; // - - - complex if condition
        <table>
        <tr><td>&nbsp; $t[] = "C++"; &nbsp; </td><td>$k[] = "language";</tr>
        <tr><td>&nbsp; $t[] = "ASP.NET"; &nbsp; </td><td>$k[] = "framework";</tr>
        <tr><td>&nbsp; $t[] = "iOS"; &nbsp; </td><td>$k[] = "os";</tr>
        </table>
        <br> &nbsp; $title = $t[0];
        <br> &nbsp; $kywd = $k[0];
        <br> &nbsp; $q = "language";
        <br> &nbsp; $list = "";
        <br> &nbsp; if ( stristr($title, $q) != "" ||
        <br> &nbsp; &nbsp; &nbsp; &nbsp;stristr($kwyd, $q) != "" ) {
        <br> &nbsp; &nbsp; $list = $title;
        <br> &nbsp; }
        <br> &nbsp; echo $list === "" ? "no suggestion" : $list;
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;
      <table cellspacing='6'><tr><td>&nbsp;</td></tr></table></div>
      <div class="right">
      <?php
        echo "<br>\n";
        $t[] = "C++";               $k[] = "language";
        $t[] = "ASP.NET";           $k[] = "framework";
        $t[] = "iOS";               $k[] = "os";
        $title = $t[0];
        $kywd = $k[0];
        $q = "language";
        $list = "";
        if ( stristr($title, $q) != "" ||
             stristr($kywd, $q) != "" ) {
          $list = $title;
        }
        echo $list === "" ? "no suggestion" : $list;
        echo '<br><br><br><br><br><br><br><br><br><br><br><br><br><br>';
      ?>
      <table cellspacing='6'><tr><td>&nbsp;</td></tr></table>
      </div>
    </div>
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_Basics.html">PHP Basics menu</a></td>
      </tr>
    </table>
  </div>

    <!-- 3.END HTML >> END -->

    <!-- 4.BEGIN JavaScript BODY >> BEGIN -->
    <script>

      var data = "data";
      	  
    </script>
    <!-- 4.END JavaScript BODY >> END -->
  </body>
</html>