<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Assignment 2 for Learning PHP and MySQL class</title>
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 650px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 65px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 300px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      .array {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
      
    </style>
  </head>
  <body>
  <div id="area">  
  <br>
	<h2>Assignment 2 - Building Blocks</h2>
    <div class="row">
      <div class="left">Use 'substr()' to isolate the text within parenthesis in the string:<br> &nbsp; "All cats (and some dogs) like fish."</div>
      <div class="middle">answer:<br>&nbsp;</div>
      <div class="right">
      <?php
        $str = "All cats (and some dogs) like fish.";
        $result = substr($str, 10, 13);
        echo '$result = "'.$result.'"';
        echo "\n<br><br>";
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">Use 'str_replace()' to find/replace strings within an array of strings:
        <br> &nbsp; $array = array ('You like to have a fun time',
		    <br> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'You are a really nice person',
		    <br> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 'Would you like to have a cup of coffee?');
        <br> &nbsp; $find = array ('fun', 'time', 'person', 'coffee' );
        <br> &nbsp; $replace = array ('excellent', 'adventure', 'individual', 'joe' );
      </div>
      <div class="middle">answer:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $array = array ('You like to have a fun time',
                        'You are a really nice person',
                        'Would you like to have a cup of coffee?');
        $find = array ('fun', 'time', 'person', 'coffee' );
        $replace = array ('excellent', 'adventure', 'individual', 'joe' );
        #--- 1. Add PHP code here to find/replace strings and print array
        $replaced = str_replace ( $find, $replace, $array );
        echo '<pre class="array">';
        print_r ( $replaced );
        echo "&nbsp;";
        echo '</pre>';
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">Use 'stristr()' to find strings in longer strings:
        <br> &nbsp; $input1 = "Hello world!"; &nbsp; $find1 = "WORLD";
        <br> &nbsp; $input2 = "Geeks for Geeks!"; &nbsp; $find2 = "K";
      </div>
      <div class="middle">answer:<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $input1 = "Hello world!";
        $find1 = "WORLD";
        $input2 = "Geeks for Geeks!";
        $find2 = "K";
        #--- 2. Add PHP code here to search and print both result strings
        echo stristr($input1, $find1),"<br>\n";
        echo stristr($input2, $find2),"<br>\n";
        echo "<br>\n";
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">Use 'foreach' and 'stristr()' to find a string within an array of longer strings:
        <br> &nbsp; $n = array('MySQL', 'PostgreSQL', 'MongoDB', 'MariaDB', 'SQLite' );
        <br> &nbsp; $find = "SQL";
      </div>
      <div class="middle">answer:<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $n = array('MySQL', 'PostgreSQL', 'MongoDB', 'MariaDB', 'SQLite' );
        $find = "SQL";
        #--- 4. Add PHP code here to search and print all matching names
        foreach ($n as $name) {
          if (stristr($name, $find) != "") {
            echo "Match found = ",$name,"<br>\n";
          }  
        }
      ?>
      </div>
    </div>
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_Building_Blocks.html">PHP Building_Blocks menu</a></td>
        <td class="rtd"><a class="rtl" href="assignment_2.html">Assignment 2 - Building_Blocks</a></td>
      </tr>
    </table>
  </div>
  </body>
</html>