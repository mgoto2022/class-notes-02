<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Increment, Function Call & Exit Examples for Learning PHP and MySQL class</title>
    <!-- Introduction
    1. There are 4 sections total added to a vscode HTML 5 blank page. 
      - Each has BEGIN, END 
    2. These instructions are downloaded from https://github.com/mgoto2022/2nd-Level-Class-Notes
    -->
    <!-- 1.BEGIN PAGE CSS STYLE BEGIN -->
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 620px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 55px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 300px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
            
    </style>
    <!-- 1.END PAGE STYLE END -->

    <!-- 2.BEGIN ADD PAGE RESOURCES >> BEGIN -->
	<script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- 2.END ADD PAGE RESOURCES >> END -->
  </head>
  <body>
    <!-- 3.BEGIN HTML BODY >> BEGIN -->
  <div id="area">  
  <br>
	<h2>Increment, Function Call & Exit Examples (pg. 171-173)</h2>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $count1 = 0; $count2 = 1; $count3 = 2;
        <br> &nbsp; $count1 = $count1 + 1;
        <br> &nbsp; $count2++;
        <br> &nbsp; $count3--;
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo '<br>&nbsp;<br>';
        $count1 = 0; $count2 = 1; $count3 = 2;
        $count1 = $count1 + 1;
        echo '$count1 = ', $count1, "<br>\n";
        $count2++;
        echo '$count2 = ', $count2, "<br>\n";
        $count3--;
        echo '$count3 = ', $count3, "<br>\n";
        echo '<br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $count1 = 1; $count2 = 1; $count3 = 1; $count4 = 1;
        <br> &nbsp; $count1 += 2;
        <br> &nbsp; $count2 -= 3;
        <br> &nbsp; $count3 *= 2;
        <br> &nbsp; $count4 /= 3;
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo '<br>&nbsp;<br>';
        $count1 = 1; $count2 = 1; $count3 = 1; $count4 = 1;
        $count1 += 2;
        echo '$count1 = ', $count1, "<br>\n";
        $count2 -= 3;
        echo '$count2 = ', $count2, "<br>\n";
        $count3 *= 2;
        echo '$count3 = ', $count3, "<br>\n";
        $count4 /= 3;
        echo '$count4 = ', $count4, "<br>\n";
        echo '<br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $result1 = substr("Your Blog is Excellent!", 1);
        <br> &nbsp; $result2 = strlen("Inco mpre hens ibil ity ");
        <br> &nbsp; $result3 = trim("junk awesome stuff junk", "junk");
        <br> &nbsp; $result4 = strtolower("Angry people SHOUT!");
        <br> &nbsp; $result5 = strtoupper("I don't SHOUT!");
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo '<br>';
        $result1 = substr("Your Blog is Excellent!",1);
        echo '$result1 = ', $result1, "<br>\n";
        $result2 = strlen("Inco mpre hens ibil ity ");
        echo '$result2 = ', $result2, "<br>\n";
        $result3 = trim("junk awesome stuff junk","junk");
        echo '$result3 = ', $result3, "<br>\n";
        $result4 = strtolower("Angry people SHOUT!");
        echo '$result4 = ', $result4, "<br>\n";
        $result5 = strtoupper("I don't SHOUT!");
        echo '$result5 = ', $result5, "<br>\n";
        echo '<br>';
      ?>
      </div>
    </div>  
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $result1 = is_numeric("7135551234");
        <br> &nbsp; $result2 = is_numeric("Hello");
        <br> &nbsp; $result3 = stristr("MySQL", "SQL");
        <br> &nbsp; $result4 = stristr("XMLDOC", "SQL");
        <br> &nbsp; $result5 = preg_match("/^\(?[0-9]{3}\)?$/","(713)");
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo '<br>';
        $result1 = is_numeric("7135551234");
        echo '$result1 = ', $result1, "<br>\n";
        $result2 = is_numeric("Hello");
        echo '$result2 = ', $result2, "<br>\n";
        $result3 = stristr("MySQL","SQL");
        echo '$result3 = ', $result3, "<br>\n";
        $result4 = stristr("XMLDOC","SQL");
        echo '$result4 = ', $result4, "<br>\n";
        $result5 = preg_match("/^\(?[0-9]{3}\)?$/","(713)");
        echo '$result5 = ', $result5, "<br>\n";
        echo '<br>';
      ?>
      </div>
    </div>  
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; echo "start program.";
        <br> &nbsp; exit("Exit stage left!");
        <br> &nbsp; echo "stop program.";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo '<br>&nbsp;<br>&nbsp;<br>';
        echo "start program.","<br>\n";
        /*  The next exit statement will terminate this .php file and skip all
            further lines in this file (e.g., the echo "stop program" statement
            as well as any remaining HTML or Javascript)
        */
        exit("Exit stage left!");
        echo "stop program.","<br>\n";
      ?>
      </div>
    </div>
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_Building_Blocks.html">PHP Building Blocks menu</a></td>
      </tr>
    </table>
  </div>

    <!-- 3.END HTML >> END -->

    <!-- 4.BEGIN JavaScript BODY >> BEGIN -->
    <script>

      var data = "data";
      	  
    </script>
    <!-- 4.END JavaScript BODY >> END -->
  </body>
</html>