<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Echo, Numbers & Strings Examples for Learning PHP and MySQL class</title>
    <!-- Introduction
    1. There are 4 sections total added to a vscode HTML 5 blank page. 
      - Each has BEGIN, END 
    2. These instructions are downloaded from https://github.com/mgoto2022/2nd-Level-Class-Notes
    -->
    <!-- 1.BEGIN PAGE CSS STYLE BEGIN -->
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 620px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 55px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 300px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #area {
        margin-left: 40px;
        margin-right: 20px;
      }
      .rtt {
        background-color: #787CB5;
        border-style: solid;
        margin-left: 40px;
        margin-right: 40px;
        margin-top: 40px;
        outline: 2px solid white;
        width: max-content;
      }
      .rtd {
        color: white;
        padding: 20px;
      }
      .rtl {
        color: white;
      }
            
    </style>
    <!-- 1.END PAGE STYLE END -->

    <!-- 2.BEGIN ADD PAGE RESOURCES >> BEGIN -->
	<script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- 2.END ADD PAGE RESOURCES >> END -->
  </head>
  <body>
    <!-- 3.BEGIN HTML BODY >> BEGIN -->
  <div id="area">  
  <br>
	<h2>Echo, Numbers & Strings Examples (pg. 167-171)</h2>
  <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; echo "Hello";
        <br> &nbsp; echo " World!&lt;br&gt;\n";
        <br> &nbsp; echo "Here I am","&lt;br&gt;\n";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo "Hello";
        echo " World!<br>\n";
        echo "Here I am","<br>\n";
        echo '<br><br><br>';
      ?>
      </div>
    </div>  
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $string1 = 'Hello'; $string2 = 'World!';
        <br> &nbsp; echo $string1, $string2, "&lt;br&gt;\n";
        <br> &nbsp; echo "$string1 $string2", "&lt;br&gt;\n";
        <br> &nbsp; echo $string1, " ", $string2, "&lt;br&gt;\n";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $string1 = 'Hello'; $string2 = 'World!';
        echo $string1,$string2, "<br>\n";
        echo "$string1 $string2", "<br>\n";
        echo $string1, " ", $string2, "<br>\n";
        echo '<br><br><br>';
      ?>  
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $pet = "bird";
        <br> &nbsp; echo "The {$pet}cage has arrived {unboxed}.", "&lt;br&gt;\n";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $pet = "bird";
        echo "The {$pet}cage has arrived.", "<br>\n";
        echo '<br><br><br>';
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $number = 2;
        <br> &nbsp; $number = 2+1;
        <br> &nbsp; $number = (2 - 1) * (4 * 5) - 17;
        <br> &nbsp; $number2 = $number + 3;
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $number = 2; echo '$number = ',$number,"<br>\n";
        $number = 2+1; echo '$number = ',$number,"<br>\n";
        $number = (2 - 1) * (4 * 5) - 17;
        echo '$number = ',(2 - 1),' * ',(4 * 5),' - ',17,' = ',$number,"<br>\n";
        $number2 = $number + 3; echo '$number2 = ',$number2,"<br>\n";
        echo '<br><br>';
      ?>
      </div>
    </div>  
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $string = "Hello World";
        <br> &nbsp; $string2 = $string." again!";
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        $string = "Hello World"; echo '$string = ', $string, "<br>\n";
        $string2 = $string." again!"; echo '$string2 = ', $string2, "<br>\n";
        echo '<br><br>';
      ?>
      </div>
    </div>  
    <div class="row">
      <div class="left">&lt;?php
        <br> &nbsp; $number = 2;
        <br> &nbsp; $string = "Hello";
        <br> &nbsp; $merged = $number.$string;
        <br> &nbsp; if ( is_numeric($string) ) {
        <br> &nbsp; &nbsp; $result = $string;
        <br> &nbsp; } else {
        <br> &nbsp; &nbsp; $result = 0;
        <br> &nbsp; }
        <br> &nbsp; $merged2 = $number + $string;
        <br>?&gt;
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
        echo '<br>';
        $number = 2; echo '$number = ', $number, "<br>\n";
        $string = "Hello"; echo '$string = ', $string, "<br>\n";
        $merged = $number.$string; echo '$merged = ', $merged, "<br>\n";
        echo '&nbsp; &nbsp; is_numeric($string) = false', "<br>\n";
        echo '<br><br>';
        if ( is_numeric($string) ) {
          $result = $string;
        } else {
          $result = 0;
        }
        echo '$result = ',$result,"<br>\n";
        echo '<br>';
        $merged2 = $number + $result; echo '$merged2 = ', $merged2, "<br>\n";
        echo '<br>';
      ?>
      </div>
    </div>  
    <br>
    <table class="rtt">
      <tr>
        <td class="rtd">Return to: &nbsp;</td>
        <td class="rtd"><a class="rtl" href="../menu.html">Main Entry menu</a></td>
        <td class="rtd"><a class="rtl" href="PHP_Building_Blocks.html">PHP Building Blocks menu</a></td>
      </tr>
    </table>
  </div>

    <!-- 3.END HTML >> END -->

    <!-- 4.BEGIN JavaScript BODY >> BEGIN -->
    <script>

      var data = "data";
      	  
    </script>
    <!-- 4.END JavaScript BODY >> END -->
  </body>
</html>