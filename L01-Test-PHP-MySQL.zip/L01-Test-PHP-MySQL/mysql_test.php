<?php
/* Program: mysql_test.php
 * Desc:    Connects to MySQL Server and 
 *          outputs settings.
 */
 echo "<html>
       <head><title>Test MySQL</title></head>
       <body>";
 $host = "localhost";
 $user = "root";
 $password = "";

 $cxn = mysqli_connect($host,$user,$password);
 $sql="SHOW DATABASES";
 $result = mysqli_query($cxn,$sql);
 if($result == false)
 {
    echo "<h4>Error: ".mysqli_error($cxn)."</h4>";
 }
 else
 {
   $mysql_version = mysqli_get_server_info($cxn);
   echo "<h2>MySQL version: &nbsp; $mysql_version</h2>";
   if(mysqli_num_rows($result) < 1)
   {
      echo "<p>No current databases</p>";
   }
   else
   {
	  echo "<style>";
	  echo "table, th, td {";
	  echo "  border: 1px solid black;";
	  echo "  border-collapse: collapse;";
	  echo "  padding: 10px;";
	  echo "}";
	  echo "</style>";
      echo "<table><tr><th>MySQL Table Names</th></tr>";
      while($row = mysqli_fetch_row($result))
      {
        echo "<tr><td>$row[0]</td></tr>";
      }
      echo "</table>";
   }
 }
?>
</body></html>
