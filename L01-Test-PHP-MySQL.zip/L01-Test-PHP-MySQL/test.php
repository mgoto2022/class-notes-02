<html>
<head><title>PHP Test</title></head>
<body>
<p>This is an HTML line</p>
<?php
  echo "<p>This is a PHP line</p>";
  phpinfo();
?>
</body></html>