
--
-- Drop Database: `PetCatalog`
--
DROP DATABASE IF EXISTS `PetCatalog`;

--
-- Create Database: `PetCatalog`;
--
CREATE DATABASE `PetCatalog`;
USE `PetCatalog`;

DROP TABLE IF EXISTS Pet;

--
-- Create Table: Pet;
--
CREATE TABLE Pet (
  petID             SERIAL,
  petName           VARCHAR(25) NOT NULL,
  petType           VARCHAR(15) NOT NULL DEFAULT 'Misc',
  petDescription    VARCHAR(255),
  price             DECIMAL(9,2),
  pix               VARCHAR(64) NOT NULL DEFAULT 'na.gif',
PRIMARY KEY(petID)  );

DROP TABLE IF EXISTS PetType;

--
-- Create Table: PetType;
--
CREATE TABLE PetType (
  petType           VARCHAR(15) NOT NULL,
  typeDescription   VARCHAR(1024),
PRIMARY KEY(petType)  );

DROP TABLE IF EXISTS Color;

--
-- Create Table: Color;
--
CREATE TABLE Color (
  petName           VARCHAR(25) NOT NULL,
  petColor          VARCHAR(25) NOT NULL,
  pix               VARCHAR(64) NOT NULL DEFAULT 'na.gif',
  videoSrc          VARCHAR(1024) DEFAULT '<iframe width="560" height="315" src="https://www.youtube.com/embed/TmXGL4BorBw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>',
PRIMARY KEY(petName,petColor)  );