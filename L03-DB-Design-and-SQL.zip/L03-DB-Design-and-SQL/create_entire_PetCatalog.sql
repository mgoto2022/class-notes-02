
--
-- Drop Database: `PetCatalog`
--
DROP DATABASE IF EXISTS `PetCatalog`;

--
-- Create Database: `PetCatalog`;
--
CREATE DATABASE `PetCatalog`;

DROP TABLE IF EXISTS `PetCatalog`.Pet;

--
-- Create Table: Pet;
--
CREATE TABLE `PetCatalog`.Pet (
  petID             SERIAL,
  petName           VARCHAR(25) NOT NULL,
  petType           VARCHAR(15) NOT NULL DEFAULT 'Misc',
  petDescription    VARCHAR(255),
  price             DECIMAL(9,2),
  pix               VARCHAR(64) NOT NULL DEFAULT 'na.gif',
PRIMARY KEY(petID)  );

DROP TABLE IF EXISTS `PetCatalog`.PetType;

--
-- Create Table: PetType;
--
CREATE TABLE `PetCatalog`.PetType (
  petType		    VARCHAR(15) NOT NULL,
  typeDescription   VARCHAR(1024),
PRIMARY KEY(petType)  );

DROP TABLE IF EXISTS `PetCatalog`.Color;

--
-- Create Table: Color;
--
CREATE TABLE `PetCatalog`.Color (
  petName           VARCHAR(25) NOT NULL,
  petColor		    VARCHAR(25) NOT NULL,
  pix		        VARCHAR(64) NOT NULL DEFAULT 'na.gif',
  videoSrc          VARCHAR(64) DEFAULT 'youtube.com/embed/TmXGL4BorBw',
PRIMARY KEY(petName,petColor)  );