
--
-- Insert data for Table: Pet
--
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("fish","Betta","small, colorful, fish",750.00,"/media/fish-betta-blue_red.jpg");