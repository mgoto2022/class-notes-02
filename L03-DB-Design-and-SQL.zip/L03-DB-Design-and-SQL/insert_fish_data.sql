
--
-- Insert data for Table: Pet
--
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("fish","Betta","small, colorful, fish",750.00,"/media/fish-betta-blue_red.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ();
  
--
-- Insert data for Table: PetType
--
INSERT INTO `PetCatalog`.PetType
 ( petType,typeDescription)
 VALUES ("fish","All fish share two traits: they live in water and they have a backbone—they are vertebrates. Apart from these similarities, however, many of the species in this group differ markedly from one another. Fin fish like salmon have gills, are covered in scales, and reproduce by laying eggs.");
  
--
-- Insert data for Table: Color
--
INSERT INTO `PetCatalog`.Color
 ( petName,petColor,pix,videoSrc)
 VALUES ("Betta","blue red","/L03-DB-Design-and-SQL/media/fish-betta-blue_red.jpg","https://www.youtube.com/embed/_st_6B96Tj0");
INSERT INTO `PetCatalog`.Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();