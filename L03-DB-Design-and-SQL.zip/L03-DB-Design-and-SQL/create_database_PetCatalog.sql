
--
-- Drop Database: `PetCatalog`
--
DROP DATABASE IF EXISTS `PetCatalog`;

--
-- Create Database: `PetCatalog`;
--
CREATE DATABASE `PetCatalog`;
