DROP TABLE IF EXISTS `PetCatalog`.Pet;

--
-- Create Table: Pet;
--
CREATE TABLE `PetCatalog`.Pet (
  petID			      SERIAL,
  petName		      VARCHAR(25) NOT NULL,
  petType		      VARCHAR(15) NOT NULL DEFAULT 'Misc',
  petDescription	VARCHAR(255),
  price			      DECIMAL(9,2),
  pix			        VARCHAR(64) NOT NULL DEFAULT 'na.gif',
PRIMARY KEY(petID)  );
