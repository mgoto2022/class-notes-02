USE `PetCatalog`;
DROP TABLE IF EXISTS Color;

--
-- Create Table: Color;
--
CREATE TABLE Color (
  petName           VARCHAR(25) NOT NULL,
  petColor          VARCHAR(25) NOT NULL,
  pix               VARCHAR(64) NOT NULL DEFAULT 'na.gif',
  videoSrc          VARCHAR(1024) DEFAULT 'https://www.youtube.com/embed/TmXGL4BorBw',
PRIMARY KEY(petName,petColor)  );