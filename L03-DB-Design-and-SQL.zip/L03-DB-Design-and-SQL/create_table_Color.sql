DROP TABLE IF EXISTS `PetCatalog`.Color;

--
-- Create Table: Color;
--
CREATE TABLE `PetCatalog`.Color (
  petName           VARCHAR(25) NOT NULL,
  petColor          VARCHAR(25) NOT NULL,
  pix               VARCHAR(64) NOT NULL DEFAULT 'na.gif',
  videoSrc          VARCHAR(1024) DEFAULT '<iframe width="560" height="315" src="https://www.youtube.com/embed/TmXGL4BorBw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>',
PRIMARY KEY(petName,petColor)  );