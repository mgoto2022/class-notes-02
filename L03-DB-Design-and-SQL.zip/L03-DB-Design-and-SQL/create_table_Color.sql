DROP TABLE IF EXISTS `PetCatalog`.Color;

--
-- Create Table: Color;
--
CREATE TABLE `PetCatalog`.Color (
  petName         VARCHAR(25) NOT NULL,
  petColor		    VARCHAR(25) NOT NULL,
  pix			        VARCHAR(64) NOT NULL DEFAULT 'na.gif',
  videoSrc        VARCHAR(64) DEFAULT 'youtube.com/embed/TmXGL4BorBw',
PRIMARY KEY(petName,petColor)  );