
--
-- Create Table: Color;
--
CREATE TABLE ‘PetCatalog’.Color (
  petName         VARCHAR(25) NOT NULL,
  petColor		  VARCHAR(15) NOT NULL,
  pix			  VARCHAR(64) NOT NULL DEFAULT “na.gif”,
PRIMARY KEY(petName,petColor)  );