USE `PetCatalog`;

--
-- Insert data for Table: Pet (add to 2nd INSERT)
--
INSERT INTO Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ('bird','Cockatoo','small, playful, bird',3000.00,'/media/bird-cockatoo-white.jpg');
INSERT INTO Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ();
  
--
-- Insert data for Table: PetType (add to 2nd INSERT)
--
INSERT INTO PetType
 ( petType,typeDescription)
 VALUES ('bird','Pet birds are very affectionate and develop a close bond with their owners.  These birds become “possessive” and tend to bond to one person in particular so it is a good idea to keep the bird interacting with all the family members.  They are very playful and have entertaining personalities.');
INSERT INTO PetType
 ( petType,typeDescription)
 VALUES ();

--
-- Insert data for Table: Color  (add to 2nd INSERT)
--
INSERT INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Cockatoo','white','/L03-DB-Design-and-SQL/media/bird-cockatoo-white.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/qnkMobV-GvU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
INSERT INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();