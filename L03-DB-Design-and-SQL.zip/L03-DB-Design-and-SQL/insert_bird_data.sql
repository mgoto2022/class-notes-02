USE `PetCatalog`;

--
-- Birds:  Insert data for Table: Pet (add VALUES to 2nd REPLACE)
--
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES (15,'Cockatoo','bird','small, playful, bird',3000.00,'/media/bird-cockatoo-white.jpg');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('bird','Pet birds are very affectionate and develop a close bond with their owners.  These birds become “possessive” and tend to bond to one person in particular so it is a good idea to keep the bird interacting with all the family members.  They are very playful and have entertaining personalities.');

--
-- Insert data for Table: Color  (add VALUES to 2nd REPLACE)
--
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Cockatoo','white','bird-cockatoo-white.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/qnkMobV-GvU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */
