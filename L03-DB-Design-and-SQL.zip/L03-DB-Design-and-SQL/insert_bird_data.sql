USE `PetCatalog`;

--
-- Insert data for Table: Pet (add to 2nd INSERT)
--
REPLACE INTO Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ('bird','Cockatoo','small, playful, bird',3000.00,'/media/bird-cockatoo-white.jpg');
/* (remove when VALUES are filled-in)
REPLACE INTO Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ();
/* (remove when VALUES are filled-in)  */
--
-- Insert data for Table: PetType (add to 2nd INSERT)
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('bird','Pet birds are very affectionate and develop a close bond with their owners.  These birds become “possessive” and tend to bond to one person in particular so it is a good idea to keep the bird interacting with all the family members.  They are very playful and have entertaining personalities.');

--
-- Insert data for Table: Color  (add to 2nd INSERT)
--
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Cockatoo','white','/L03-DB-Design-and-SQL/media/bird-cockatoo-white.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/qnkMobV-GvU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
/* (remove when VALUES are filled-in)
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();
/* (remove when VALUES are filled-in)  */
