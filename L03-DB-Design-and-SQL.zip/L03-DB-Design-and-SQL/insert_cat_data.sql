
--
-- Insert data for Table: Pet
--
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("Burmese","cat","small, dark brown, cat",700.00,
  "/media/cat-burmese-light_brown.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("Persian","cat","docile, black, cat",1400.00,
  "/media/cat-persian-black.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("Scottish Fold","cat","playful, light brown, cat",350.00,
  "/media/cat-scottish_fold-gray_brown.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("Siamese","cat","social, white w/ black tips, cat",700.00,
  "/media/cat-siamese-white_black.jpg");
  
--
-- Insert data for Table: PetType
--
INSERT INTO `PetCatalog`.PetType
 ( petType,typeDescription)
 VALUES ("cat","Cats are very sensitive to their interpersonal space.  They often do not have strict social hierarchies. They are also subtle in their display of friendly, or affiliative behaviors. Once aroused into threatening behaviors, cats can remain so for quite a long time.");

--
-- Insert data for Table: Color
--
INSERT INTO `PetCatalog`.Color
 ( petType,typeDescription)
 VALUES ("Burmese","light brown",
  "/media/cat-burmese-light_brown.jpg",
  "https://www.youtube.com/embed/cRBEL57B6ok");
INSERT INTO `PetCatalog`.PetType
 ( petType,typeDescription)
 VALUES ("Persian","black",
  "/media/cat-persian-black.jpg",
  "https://www.youtube.com/embed/QqZ7YkTdGIY");
INSERT INTO `PetCatalog`.Color
 ( petType,typeDescription,typeVideoSrc)
 VALUES ("Scottish Fold","gray brown",
  "/media/cat-scottish_fold-gray_brown.jpg",
  "https://www.youtube.com/embed/mlNJMpBtNzo");
INSERT INTO `PetCatalog`.PetType
 ( petType,typeDescription,typeVideoSrc)
 VALUES ("Siamese","white brown",
  "https://www.youtube.com/embed/2LyVbxmMxqE");