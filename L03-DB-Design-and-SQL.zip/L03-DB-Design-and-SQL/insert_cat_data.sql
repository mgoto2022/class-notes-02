
--
-- Insert data for Table: Pet
--
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ('Burmese','cat','small, light brown, cat',700.00,
  '/media/cat-burmese-light_brown.jpg');
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ('Persion','cat','docile, black, cat',1400.00,
  '/media/cat-persian-black.jpg');
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ('Scottish Fold','cat','playful, gray brown, cat',350.00,
  '/media/cat-scottish_fold-gray_brown.jpg');
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ('Siamese','cat','social, white w/ black tips, cat',700.00,
  '/media/cat-siamese-white_black.jpg');
  
--
-- Insert data for Table: PetType
--
INSERT INTO `PetCatalog`.PetType
 ( petType,typeDescription)
 VALUES ('cat','Cats are very sensitive to their interpersonal space.  They often do not have strict social hierarchies. They are also subtle in their display of friendly, or affiliative behaviors. Once aroused into threatening behaviors, cats can remain so for quite a long time.');
  
--
-- Insert data for Table: Color
--
INSERT INTO `PetCatalog`.Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Burmese','light brown','/L03-DB-Design-and-SQL/media/cat-burmese-light_brown.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/cRBEL57B6ok" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
INSERT INTO `PetCatalog`.Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Persian','black','/L03-DB-Design-and-SQL/media/cat-persian-black.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/QqZ7YkTdGIY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
INSERT INTO `PetCatalog`.Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Scottish Fold','gray brown','/L03-DB-Design-and-SQL/media/cat-scottish_fold-gray_brown.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/mlNJMpBtNzo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
INSERT INTO `PetCatalog`.Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Siamese','white black','/L03-DB-Design-and-SQL/media/cat-siamese-white_black.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/2LyVbxmMxqE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
