
--
-- Insert data for Table: Pet
--
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("cat","Burmese","small, dark brown, cat",700.00,"/media/cat-burmese-dark_brown.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("cat","Persion","docile, black, cat",1400.00,"/media/cat-persian-black.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("cat","Scottish Fold","playful, light brown, cat",350.00,
  "/media/cat-scottish_fold-light_brown.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("cat","Siamese","social, white w/ black tips, cat",700.00,
  "/media/cat-siamese-white_black.jpg");