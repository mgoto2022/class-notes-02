DROP TABLE IF EXISTS `PetCatalog`.PetType;

--
-- Create Table: PetType;
--
CREATE TABLE `PetCatalog`.PetType (
  petType           VARCHAR(15) NOT NULL,
  typeDescription   VARCHAR(1024),
PRIMARY KEY(petType)  );
