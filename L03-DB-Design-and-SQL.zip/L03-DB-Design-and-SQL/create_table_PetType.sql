USE `PetCatalog`;
DROP TABLE IF EXISTS PetType;

--
-- Create Table: PetType;
--
CREATE TABLE PetType (
  petType           VARCHAR(15) NOT NULL,
  typeDescription   VARCHAR(1024),
PRIMARY KEY(petType)  );
