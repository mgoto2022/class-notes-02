
--
-- Create Table: PetType;
--
CREATE TABLE ‘PetCatalog’.PetType (
  petType		      VARCHAR(15) NOT NULL,
  typeDescription VARCHAR(255),
  typeVideoSrc    VARCHAR(64),
PRIMARY KEY(petType)  );
