
--
-- Insert data for Table: Pet
--
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("horse","Clydesdale","large powerful horse",4000.00,
  "/media/horse-clydesdale-brown_white_legs.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("horse","Pegasus","winged mare",80000.00,"/media/horse-pegasus-white.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("horse","Unicorn","white steed with spiral forehead horn",50000.00,"/media/horse-unicorn-white.jpg");