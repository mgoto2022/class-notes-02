USE `PetCatalog`;

--
-- Horses:  Insert data for Table: Pet
--
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (4001,"Clydesdale","horse","large powerful horse",4000.00,
  "horse-clydesdale-brown_white_legs.jpg");
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (4002,"Pegasus","horse","wise winged mare",80000.00,"horse-pegasus-white.jpg");
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (4003,"Unicorn","horse","peaceful steed with spiral forehead horn",50000.00,"horse-unicorn-white.jpg");
   
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType ( petType,typeDescription)
 VALUES ('horse','Horses have oval-shaped hooves, long tails, short hair, long slender legs, muscular and deep torso build, long thick necks, and large elongated heads. The mane is a region of coarse hairs, which extends along the dorsal side of the neck in both domestic and wild species.');
   
--
-- Insert data for Table: Color
--
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Clydesdale','brown white','horse-clydesdale-brown_white_legs.jpg','https://www.youtube.com/embed/_m7iKHUWq8M');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Pegasus','white','horse-pegasus-white.jpg','https://www.youtube.com/embed/sMGgc9nPtQU');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Unicorn','white','horse-unicorn-white.jpg','https://www.youtube.com/embed/uWkz0IggQjw');
