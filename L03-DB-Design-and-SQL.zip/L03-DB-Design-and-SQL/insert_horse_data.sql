USE `PetCatalog`;

--
-- Insert data for Table: Pet
--
REPLACE INTO Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("Clydesdale","horse","large powerful horse",4000.00,
  "/media/horse-clydesdale-brown_white_legs.jpg");
REPLACE INTO Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("Pegasus","horse","winged mare",80000.00,"/media/horse-pegasus-white.jpg");
REPLACE INTO Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("Unicorn","horse","white steed with spiral forehead horn",50000.00,"/media/horse-unicorn-white.jpg");
   
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('horse','Horses have oval-shaped hooves, long tails, short hair, long slender legs, muscular and deep torso build, long thick necks, and large elongated heads. The mane is a region of coarse hairs, which extends along the dorsal side of the neck in both domestic and wild species.');
   
--
-- Insert data for Table: Color
--
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Clydesdale','brown white','/L03-DB-Design-and-SQL/media/horse-clydesdale-brown_white_legs.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/_m7iKHUWq8M" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Pegasus','white','/L03-DB-Design-and-SQL/media/horse-pegasus-white.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/sMGgc9nPtQU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Unicorn','white','/L03-DB-Design-and-SQL/media/horse-unicorn-white.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/uWkz0IggQjw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
