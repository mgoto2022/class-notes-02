USE `PetCatalog`;

--
-- Dogs:  Insert data for Table: Pet (add VALUES to 2nd REPLACE)
--
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (3001,'Beagle','dog','small scent hound dog',500.00,
 'dog-beagle-white_brown_black.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (3002,'Bulldog','dog','sweet, devoted, easygoing dog',3000.00,'dog-bulldog-white_brown.jpg');
/*--- 1. (remove this comment line when VALUES are filled-in)
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (3003,   );
/* (can be removed if VALUES are filled-in)  */
  
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType ( petType,typeDescription)
 VALUES ('dog','Dogs’ sense of smell is at least 40x better than ours.  Some have sich good noses that they can sniff our medical problems.  Some dogs are incredible swimmers.  Dogs pant to cool down instead of sweating.  Along with their noses, their hearing is super sensitive.');
  
--
-- Insert data for Table: Color (add VALUES to 2nd REPLACE)
--
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Beagle','white brown black','dog-beagle-white_brown_black.jpg','https://www.youtube.com/embed/SSoV5gDGeN4');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Bulldog','white brown','dog-bulldog-white_brown.jpg','https://www.youtube.com/embed/bwWtPsug4Ls');
/*--- 2. (remove this comment line when VALUES are filled-in)
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES (   );
/* (can be removed if VALUES are filled-in)  */
