
--
-- Insert data for Table: Pet
--
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("dog","Beagle","small scent hound dog",550.00,
 "/media/dog-beagle-white_brown_black.jpg");
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ();
  
--
-- Insert data for Table: PetType
--
INSERT INTO `PetCatalog`.PetType
 ( petType,typeDescription)
 VALUES ("dog","Dogs’ sense of smell is at least 40x better than ours.  Some have sich good noses that they can sniff our medical problems.  Some dogs are incredible swimmers.  Dogs pant to cool down instead of sweating.  Along with their noses, their hearing is super sensitive.");
  
--
-- Insert data for Table: Color
--
INSERT INTO `PetCatalog`.Color
 ( petName,petColor,pix,videoSrc)
 VALUES ("Beagle","white brown black","/L03-DB-Design-and-SQL/media/dog-beagle-white_brown_black.jpg","https://www.youtube.com/embed/SSoV5gDGeN4");
INSERT INTO `PetCatalog`.Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();