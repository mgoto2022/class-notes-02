USE `PetCatalog`;

--
-- Insert data for Table: Pet (add VALUES to 2nd REPLACE)
--
REPLACE INTO Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ('Beagle','dog','small scent hound dog',500.00,
 '/media/dog-beagle-white_brown_black.jpg');
/* (remove when VALUES are filled-in)
REPLACE INTO Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ();
/* (remove when VALUES are filled-in)  */
  
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('dog','Dogs’ sense of smell is at least 40x better than ours.  Some have sich good noses that they can sniff our medical problems.  Some dogs are incredible swimmers.  Dogs pant to cool down instead of sweating.  Along with their noses, their hearing is super sensitive.');
  
--
-- Insert data for Table: Color (add VALUES to 2nd REPLACE)
--
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ('Beagle','white brown black','/L03-DB-Design-and-SQL/media/dog-beagle-white_brown_black.jpg','<iframe width="560" height="315" src="https://www.youtube.com/embed/SSoV5gDGeN4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
/* (remove when VALUES are filled-in)
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();
/* (remove when VALUES are filled-in)  */
