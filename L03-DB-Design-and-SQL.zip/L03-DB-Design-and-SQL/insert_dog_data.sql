
--
-- Insert data for Table: Pet
--
INSERT INTO `PetCatalog`.Pet
 ( petName,petType,petDescription,price,pix)
 VALUES ("dog","Beagle","small, hound dog",750.00,"/media/dog-beagle-white_brown_black.jpg");