<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Numbers & Strings Examples for Learning PHP and MySQL class</title>
    <!-- Introduction
    1. There are 4 sections total added to a vscode HTML 5 blank page. 
      - Each has BEGIN, END 
    2. These instructions are downloaded from https://github.com/mgoto2022/2nd-Level-Class-Notes
    -->
    <!-- 1.BEGIN PAGE CSS STYLE BEGIN -->
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 650px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 55px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 300px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #menu {
        margin-left: 40px;
        margin-right: 20px;
      }
      
    </style>
    <!-- 1.END PAGE STYLE END -->

    <!-- 2.BEGIN ADD PAGE RESOURCES >> BEGIN -->
	<script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- 2.END ADD PAGE RESOURCES >> END -->
  </head>
  <body>
    <!-- 3.BEGIN HTML BODY >> BEGIN -->
  <div id="menu">  
  <br>
	<h2>Numbers & Strings Examples</h2>
    <div class="row">
      <div class="left">$result = 1 + 2 * 4 + 1;</div>
      <div class="middle">yields:</div>
      <div class="right">
      <?php
          $result = 1 + 2 * 4 + 1;
          echo '$result = '.$result;
        ?>
      </div>
    </div>
    <div class="row">
      <div class="left">$result = ((1 + 2) * 4) + 1;</div>
      <div class="middle">yields:</div>
      <div class="right">
      <?php
          $result = ((1 + 2) * 4) + 1;
          echo '$result = '.$result;
        ?>
      </div>
    </div>
    <div class="row">
      <div class="left">$remainder = 8 % 3; &nbsp; &nbsp; &nbsp; &nbsp; // '%' is known as the modulo operator</div>
      <div class="middle">yields:</div>
      <div class="right">
      <?php
          $rem = 8 % 3;
          echo '$remainder = '.$rem;
        ?>
      </div>
    </div>
    <div class="row">
      <div class="left"><i>//>>> &nbsp; To join strings, use '.'</i><br>
        $string1 = 'Hello';<br>
        $string2 = 'World!';<br>
        echo $string1.$string2;</div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
          $string1 = 'Hello';
          $string2 = 'World!';
          echo $string1.$string2;
        ?>
      <br>&nbsp;<br>&nbsp;<br>&nbsp;  
      </div>
    </div>
    <div class="row">
      <div class="left"><i>//>>> &nbsp; To show dollars, use number_format</i><br>
        $price = 25000;<br>
        $f_price = '$'.number_format($price,2);</div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
          $price = 25000;
          $f_price = '$'.number_format($price,2);
          echo $f_price;
        ?>
      <br>&nbsp;<br>&nbsp;  
      </div>
    </div>
    <div class="row">
      <div class="left"><i>//>>> &nbsp; To embed a single quote, use back-slash</i><br>
        $string = 'This is Tim\'s house'; &nbsp;<br>
        echo $string;</div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
          $string = 'This is Tim\'s house';
          echo $string;
        ?>
      <br>&nbsp;<br>&nbsp; 
      </div>
    </div>
    <div class="row">
      <div class="left"><i>//>>> &nbsp; Use single-quotes for a literal and double-quotes for a variable</i><br>
        $age = 12;<br>
        $literal = '$age';<br>
        $variable = "$age";<br>
        echo $literal.' = '.$variable;</div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
          $age = 12;
          $literal = '$age';
          $variable = "$age";
          echo $literal.' = '.$variable;
        ?>
      <br>&nbsp;<br>&nbsp;<br>&nbsp;<br>&nbsp; 
      </div>
    </div>
  <br>
  </div>

    <!-- 3.END HTML >> END -->

    <!-- 4.BEGIN JavaScript BODY >> BEGIN -->
    <script>

      var data = "data";
      	  
    </script>
    <!-- 4.END JavaScript BODY >> END -->
  </body>
</html>