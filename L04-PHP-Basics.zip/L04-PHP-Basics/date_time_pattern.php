<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Date, Time & Pattern Examples for Learning PHP and MySQL class</title>
    <!-- Introduction
    1. There are 4 sections total added to a vscode HTML 5 blank page. 
      - Each has BEGIN, END 
    2. These instructions are downloaded from https://github.com/mgoto2022/2nd-Level-Class-Notes
    -->
    <!-- 1.BEGIN PAGE CSS STYLE BEGIN -->
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 650px;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 55px;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 300px;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #menu {
        margin-left: 40px;
        margin-right: 20px;
      }
      
    </style>
    <!-- 1.END PAGE STYLE END -->

    <!-- 2.BEGIN ADD PAGE RESOURCES >> BEGIN -->
	<script type='text/javascript' src="http://yui.yahooapis.com/3.17.2/build/yui/yui-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/1.0.0/handlebars.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <!-- 2.END ADD PAGE RESOURCES >> END -->
  </head>
  <body>
    <!-- 3.BEGIN HTML BODY >> BEGIN -->
  <div id="menu">  
  <br>
	<h2>Date, Time & Pattern Examples</h2>
    <div class="row">
      <div class="left">$mmddyyyy = date("m/d/Y");<br>
        $ddmmmyyyy = date("d-M-Y");<br>
        $yyyymmdd = date("Y-m-d");<br>
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
          date_default_timezone_set("America/Chicago");
          echo '$mmddyyyy = &nbsp; &nbsp;'.date("m/d/Y").'<br>';
          echo '$ddmmmyyyy = '.date("d-M-Y").'<br>';
          echo '$yyyymmdd = &nbsp; &nbsp;'.date("Y-m-d").'<br>';
        ?>
      </div>
    </div>
    <div class="row">
      <div class="left">$hhmmss = date("H:i:s");<br>
        $hhmmss_A = date("h:i:s A");<br>
        $hhmm_a = date("h:i a");<br>
      </div>
      <div class="middle">yields:<br>&nbsp;<br>&nbsp;</div>
      <div class="right">
      <?php
          date_default_timezone_set("America/Chicago");
          echo '$hhmmss =&nbsp; &nbsp; &nbsp;'.date("H:i:s").'<br>';
          echo '$hhmmss_A = '.date("h:i:s A").'<br>';
          echo '$hhmm_a =&nbsp; &nbsp; &nbsp;'.date("h:i a").'<br>';
        ?>
      </div>
    </div>
    <div class="row">
      <div class="left">$timestamp = time();</div>
      <div class="middle">yields:</div>
      <div class="right">
      <?php
          date_default_timezone_set("America/Chicago");
          echo '$timestamp = '.time().'<br>';
        ?>
      </div>
    </div>
    <div class="row">
      <div class="left">pattern "/^[A-Z].*$/" applied to <b>I win</b>, <b>Yes</b>, and <b>no</b>
      </div>
      <div class="middle">&nbsp;</div>
      <div class="right">
      <?php
        if (preg_match("/^[A-Z].*$/","I win")) {
          $match1 = "match";
        } else {
          $match1 = "no-match";
        }

        if (preg_match("/^[A-Z].*$/","Yes")) {
          $match2 = "match";
        } else {
          $match2 = "no match";
        }

        if (preg_match("/^[A-Z].*$/","no")) {
          $match3 = "match";
        } else {
          $match3 = "no match";
        }

        echo $match1.' &nbsp; '.$match2.' &nbsp; '.$match3.'<br>';
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">pattern "/^[0-9]{5}(\-[0-9]{4})?$/" applied to <b>90210</b>, <b>90210-6789</b>, and <b>9021</b>
      </div>
      <div class="middle">&nbsp;</div>
      <div class="right">
      <?php
        if (preg_match("/^[0-9]{5}(\-[0-9]{4})?$/","90210")) {
          $match1 = "match";
        } else {
          $match1 = "no-match";
        }

        if (preg_match("/^[0-9]{5}(\-[0-9]{4})?$/","90210-6789")) {
          $match2 = "match";
        } else {
          $match2 = "no match";
        }

        if (preg_match("/^[0-9]{5}(\-[0-9]{4})?$/","9021")) {
          $match3 = "match";
        } else {
          $match3 = "no match";
        }

        echo $match1.' &nbsp; '.$match2.' &nbsp; '.$match3.'<br>';
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">pattern "/^\(?[0-9]{3}\)?$/" applied to <b>(713)</b>, <b>713</b>, and <b>7123</b>
      </div>
      <div class="middle">&nbsp;</div>
      <div class="right">
      <?php
        if (preg_match("/^\(?[0-9]{3}\)?$/","(713)")) {
          $match1 = "match";
        } else {
          $match1 = "no-match";
        }

        if (preg_match("/^\(?[0-9]{3}\)?$/","713")) {
          $match2 = "match";
        } else {
          $match2 = "no match";
        }

        if (preg_match("/^\(?[0-9]{3}\)?$/","7123")) {
          $match3 = "match";
        } else {
          $match3 = "no match";
        }

        echo $match1.' &nbsp; '.$match2.' &nbsp; '.$match3.'<br>';
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">pattern "/^(\-| )?[0-9]{3}$/" applied to <b>&nbsp;123</b>, <b>-123</b>, and <b>1234</b>
      </div>
      <div class="middle">&nbsp;</div>
      <div class="right">
      <?php
        if (preg_match("/^(\-| )?[0-9]{3}$/"," 123")) {
          $match1 = "match";
        } else {
          $match1 = "no-match";
        }

        if (preg_match("/^(\-| )?[0-9]{3}$/","-123")) {
          $match2 = "match";
        } else {
          $match2 = "no match";
        }

        if (preg_match("/^(\-| )?[0-9]{3}$/","1234")) {
          $match3 = "match";
        } else {
          $match3 = "no match";
        }

        echo $match1.' &nbsp; '.$match2.' &nbsp; '.$match3.'<br>';
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">pattern "/^\-[0-9]{4}$/" applied to <b>-5678</b>, <b>-9012</b>, and <b>-567</b>
      </div>
      <div class="middle">&nbsp;</div>
      <div class="right">
      <?php
        if (preg_match("/^\-[0-9]{4}$/","-5678")) {
          $match1 = "match";
        } else {
          $match1 = "no-match";
        }

        if (preg_match("/^\-[0-9]{4}$/","-9012")) {
          $match2 = "match";
        } else {
          $match2 = "no match";
        }

        if (preg_match("/^\-[0-9]{4}$/","-567")) {
          $match3 = "match";
        } else {
          $match3 = "no match";
        }

        echo $match1.' &nbsp; '.$match2.' &nbsp; '.$match3.'<br>';
      ?>
      </div>
    </div>
  <br>
  </div>

    <!-- 3.END HTML >> END -->

    <!-- 4.BEGIN JavaScript BODY >> BEGIN -->
    <script>

      var data = "data";
      	  
    </script>
    <!-- 4.END JavaScript BODY >> END -->
  </body>
</html>