<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Assigned Problems for Learning PHP and MySQL class</title>
    <style>

      body {
        background-color: #B0B3D6;
        font-family: Arial, Helvetica, sans-serif;
      }
      .left {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 50%;
      }
      .middle {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 5%;
      }
      .right {
        float: left;
        font-size: 20px;
        padding: 20px;
        outline: 1px solid white;
        width: 35%;
      }
      /* Clear floats after the columns */
      .row:after {
        content: "";
        display: table;
        clear: both;
      }
      #menu {
        margin-left: 40px;
        margin-right: 80px;
      }
      
    </style>
  </head>
  <body>
  <div id="menu">  
  <br>
	<h2>Assigned Problems</h2>
    <div class="row">
      <div class="left">add 1 & 2, mpy by 4 and divide by 3</div>
      <div class="middle">answer:</div>
      <div class="right">
      <?php
        $result = (1 + 2) * 4 / 3;
        echo '$result = '.$result;
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">add 1 & 3, mpy by 4 and modulo by 3</div>
      <div class="middle">answer:</div>
      <div class="right">
      <?php
        #--- 1. Add PHP code here to compute result and show result
        
        
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">write: [Tim's sister's name is Kathy.] using variables for the names</div>
      <div class="middle">answer:</div>
      <div class="right">
      <?php
        $name1 = 'Tim';
        $name2 = 'Kathy';
        #--- 2. Add PHP code here to build result string using \' and show result
        
        
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">show today's date in unabbreviated text format (see pg. 151)</div>
      <div class="middle">answer:</div>
      <div class="right">
      <?php
        date_default_timezone_set("America/Chicago");
        #--- 3. Add PHP code here to build unabbreviated text date and show result
        
        
      ?>
      </div>
    </div>
    <div class="row">
      <div class="left">create a pattern to match phone numbers (see pg. 159):<br>
        &nbsp; (713)123-4567 [valid] &nbsp; 71345-6789 [invalid]<br>
      </div>
      <div class="middle">answer:<br>&nbsp;</div>
      <div class="right">
      <?php
        $phone1 = '(713)123-4567';
        $phone2 = '71345-6789';
        $match1 = '?';
        $match2 = '?';
        #--- 4. Add PHP if statements to see if $phone1 and $phone2 are valid/invalid

        
        
        



        
        echo "$phone1 is $match1<br>";
        echo "$phone2 is $match2<br>";
      ?>
      </div>
    </div>
  <br>
  </div>
  </body>
</html>