USE MemberDirectory;

--
-- Insert data for Table: Member
--
REPLACE INTO Member
 ( loginName,lastName,firstName,street,city,state,zip,email,phone,staff)
 VALUES ("john_doe@gmail.com","Doe","John","1234 Cherry Lane","Green Hills",
    "MT","20252-2047","john_doe@gmail.com","(123)-555-1234","");
REPLACE INTO Member
 ( loginName,lastName,firstName,street,city,state,zip,email,phone,staff)
 VALUES ("john_smith@yahoo.com","Smith","John","5678 Cherry Lane","Chicago",
    "IL","60614-7924","john_smith@yahoo.com","(123)-555-5678","");
REPLACE INTO Member
 ( loginName,password,lastName,firstName,street,city,state,zip,email,phone,staff)
 VALUES ("staff@pstore.com","staff","staff","the","1413 Kirby Drive","Houston",
    "TX","77019-1411","staff@pstore.com","(456)-555-1234","MC");

--
-- Insert data for Table: Login
--
REPLACE INTO Login ( loginName,loginTime)
 VALUES ("John_Doe@acme.com",NOW());
REPLACE INTO Login ( loginName,loginTime)
 VALUES ("John_Smith@acme.com",NOW());
