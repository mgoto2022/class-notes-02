<?php
  /* Program: PetCatalog.php
   * Desc:    Displays a list of pet categories from the
   *           PetType table. Includes descriptions.
   *          Displays radio buttons for user to check.
   */
  session_start();
  $Welcome = $_SESSION['welcome'];
  $petShop = $_SESSION['petshop'];
  $showPets = $_SESSION['showpets'];
?>
<html>
<head>
  <title>Pet Categories</title>
  <style>
    h1 { font-size: 80px; font-weight: bolder; }
    h2 { font-size: 40px; font-weight: bolder; }
    h3 { font-size: 35px; font-weight: bolder; }
    h4 { font-size: 30px; font-weight: bolder; }
    p  { font-size: 20px; font-family: Arial, sans-serif; }
    #page { margin: 12px; }
    .rtt { border-style: solid; margin: 8px; outline: 2px solid grey; }
    .rtd { padding: 10px; }
  </style>
</head>
<body>
<div style="text-align: center">
  <img src="media/red-white-awning.jpg" height="100" width="1000" alt="awning" />
  <?php echo "<h3>$Welcome</h3>" ?>
</div>
<div id='page'>
<?php
  include("basePet.php");	                             #12

  $cxn = mysqli_connect($host,$user,$passwd,$dbname)	 #14
         or die ("couldn't connect to server");

  /* Select all categories from PetType table */
  $query = "SELECT * FROM PetType ORDER BY petType";	 #18
  $result = mysqli_query($cxn,$query)
            or die ("Couldn't execute query.");	       #20

  /* Display text before form */
  echo "<div style='margin-left: .1in'>\n
  <h1 style='text-align: center'>Pet Catalog - Categories</h1>\n
  <h2 style='text-align: center'>The following animal 
      friends are waiting for you.</h2>\n
  <p style='text-align: center'>Find just what you want
      and hurry in to the store to pick up your 
      new friend.</p>
  <h3>What kind of pet are you interested in?</h3>\n";

  /* Create form containing selection list */
  echo "<form action='$showPets' method='POST'>\n"; #33
  echo "<table cellpadding='5' border='1'>\n";
  $counter=1;	                                         #35
  while($row = mysqli_fetch_assoc($result))	           #36
  {
    extract($row);                                   	 #38
    echo "<tr><td valign='top' width='15%' 
                  style='font-weight: bold; 
                  font-size: 1.2em'>\n";
    echo "<h4><input type='radio' name='interest' 
                 value='$petType'";                 	 #43
    if( $counter == 1 )                              	 #44
    {
      echo "checked='checked'";
    }
    echo ">$petType</h4></td>\n";                           #48
    echo "<td><p>$typeDescription</p></td></tr>";           	 #49
    $counter++;                                      	 #50
  }
  echo "</table>\n";
  echo "<p><input type='submit' value='Select Pet Type'>  
        </form></p>\n";                                #54
?>
</div>
</div>
<br>
<table class="rtt">
  <tr>
    <td class="rtd">Return to: &nbsp;</td>
    <td class="rtd"><a href="Pet_Store_Application.html">Pet Store Applications menu</a></td>
    <td class="rtd"><a href="<?php echo $petShop; ?>">Pet Store Welcome page</a></td>
  </tr>
</table>
</body></html>