<?php
  /* Program: PetShopFrontMembers.php
   * Desc:    Displays opening page for Pet Store.
   */
?>
<html>
<head>
<title>Pet Store Front Page</title>
  <style type='text/css'>
    #banner { text-align: center; }
    #main { text-align: center; position: relative; }
    .first { padding-top: 10px; }
    #rightcol { background-color: black; color: white; link: white;
      position: absolute; right: 0; top: 20px; width: 18%; }
    #rightcol ul { text-align: left; }
    #last { padding-bottom: 3em; };
  </style>
</head>
<body>
<div id="banner">
  <img src="media/red-white-awning.jpg" alt="awning" />
  <img src="media/pet-store.jpg" alt="Pet Store" />
  <h1>Welcome</h1>
</div>
<div id="main">
  <p class="first">
  <a href="assignment_6-PetCtlgMG.php">
    <img src="media/cat-scottish_fold-gray_white.jpg" 
      width="500" height="530" alt="kitten picture" />
  </a>
  </p>
  <h2>Looking for a new friend?</h2>
  <p>Check out our 
    <a href="assignment_6-PetCtlgMG.php">Pet Catalog.</a>
    <br /> We may have just what you're looking for.</p>
  
  <div id="rightcol">
    <p class="first">
    <b>Looking for <br />more?</b></p>
    <ul>
      <li>special deals?</li>
      <li>pet information?</li>
      <li>good conversation?</li>
    </ul>
    <p>Try the
       <br /><a href="Login_reg.php" 
               style="color: white">Members Only</a> 
       <br />section <br />of our store</></p>
    <p id="last"><b>It's free!</b></p>
  </div>
</div>
</body></html>