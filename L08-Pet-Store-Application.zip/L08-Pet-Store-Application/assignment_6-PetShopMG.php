<?php
  /* Program: PetShopFrontMembers.php
   * Desc:    Displays opening page for Pet Store.
   */
  session_start();
  /* #--- 1.
  - Replace "Welcome to my Pet Store" with the title line
    text that you want to appear just below the awning */
  $_SESSION['welcome'] = "Welcome to the Marvelous Pet Store";
  /* Do not modify the following lines */
  $_SESSION['petctlg'] = "assignment_6-PetCtlgMG.php";
  $_SESSION['petshop'] = "assignment_6-PetShopMG.php";
  $_SESSION['showpets'] = "assignment_6-ShowPetsMG.php";
  $Welcome = $_SESSION['welcome'];
  $petCtlg = $_SESSION['petctlg'];
?>
<html>
<head>
  <title>Pet Store Front Page</title>
  <style type='text/css'>
    h1 { font-size: 80px; font-weight: bolder; }
    h2 { font-size: 40px; font-weight: bolder; }
    h3 { font-size: 35px; font-weight: bolder; }
    h4 { font-size: 30px; font-weight: bolder; }
    p  { font-size: 20px; font-family: Arial, sans-serif; }
    #banner { text-align: center; }
    #main { text-align: center; position: relative; }
    .first { padding-top: 10px; }
    #rightcol { background-color: black; color: white; link: white;
      position: absolute; right: 0; top: 20px; width: 18%; }
    #rightcol ul { text-align: left; }
    #last { padding-bottom: 3em; };
  </style>
</head>
<body>
<div id="banner">
  <img src="media/red-white-awning.jpg" alt="awning" />
  <img src="media/pet-store.jpg" alt="Pet Store" />
  <?php echo "<h1>$Welcome</h1>" ?>
</div>
<div id="main">
  <p class="first">
  <?php echo "<a href='$petCtlg'>";?>
    <img src="media/cat-scottish_fold-gray_white.jpg" 
      width="500" height="530" alt="kitten picture" />
  </a>
  </p>
  <h2>Looking for a new friend?</h2>
  <h4>Check out our 
  <?php echo "<a href='$petCtlg'>";?>Pet Catalog.</a>
    <br /> We may have just what you're looking for.</h4>
  
  <div id="rightcol">
    <p class="first">
    <b>Looking for <br />more?</b></p>
    <ul>
      <li>special deals?</li>
      <li>pet information?</li>
      <li>good conversation?</li>
    </ul>
    <p>Try the
       <br /><a href="Login_reg.php" 
               style="color: white">Members Only</a> 
       <br />section <br />of our store</></p>
    <p id="last"><b>It's free!</b></p>
  </div>
</div>
</body></html>