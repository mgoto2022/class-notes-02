<?php
  include("basePet.php");

  // Connect to MySQL and select Database
  $cxn = mysqli_connect($host,$user,$passwd,$dbname)
         or die ("<p>Unable to connect to server</p>");

  // Retrieve selected pet type
  $sel = $_GET['sel'];

  // Build and send query
  $query = "SELECT petType FROM pettype WHERE petType != ''";
  $result = mysqli_query($cxn,$query) or die(mysqli_error($cxn));

  // Convert results into <option ... > ... </option> rows
  while($row = mysqli_fetch_assoc($result)) {
    extract($row);
    // If selected type is found, add 'selected' attribute
    if ( $petType == $sel ) {
      $selected = " selected";
    } else {
      $selected = "";
    }
    $type = ucfirst($petType);
    echo "<option value=\"", $petType, "\"",
  	  $selected, ">", $type, "</option>\n";
  }
?>

