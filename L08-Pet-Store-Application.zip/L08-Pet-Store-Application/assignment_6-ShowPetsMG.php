<?php
  /* Program: ShowPets.php
   * Desc:    Displays all the pets in a category. The
   *          category is passed in a variable from a 
   *          submitted form. A "Select another kind of
   *          pet?" button and a select list of the kinds
   *          of pets uses AJAX to obtain the latest list
   *          of pet categries.
   * 
   *          The information for each pet is displayed on
   *          a single line, unless the pet comes in more
   *          than one color. If the pet does come in
   *          colors, a single line is displayed without a
   *          picture or video icon, and a line for each
   *          color, with pictures/icons, is displayed
   *          following the single line. Small pictures/
   *          icons are displayed so that a user may click
   *          on them to show modal popup windows.
   */
  session_start();
  $Welcome = $_SESSION['welcome'];
  $petCtlg = $_SESSION['petctlg'];
  $petShop = $_SESSION['petshop'];
  $showPets = $_SESSION['showpets'];
?>
<html>
<head>
  <title>Pet Catalog</title>
  <style>
    h1 { font-size: 80px; font-weight: bolder; }
    h2 { font-size: 40px; font-weight: bolder; }
    h3 { font-size: 35px; font-weight: bolder; }
    h4 { font-size: 30px; font-weight: bolder; }
    .t { font-size: 20px; font-family: Arial, sans-serif; }
    #page { margin: 12px; }
    .rtt { border-style: solid; margin: 8px; outline: 2px solid grey; }
    .rtd { padding: 10px; }
  </style>
  <!---
  - The following 'libraries' support modal windows and AJAX --->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  /*
  - Add JavaScript routines to:
  -   Retrieve a list of the kinds of pets from the database in
  -     order to initialize the selection list
  -   Update the selection list from database, when the user
  -     clicks on the list
  -   Open the picture modal popup window when the user clicks on
  -     the small pet picture
  -   Open the video modal popup window when the user clicks on
  -     the YouTube icon
  -   Stop the YouTube video when the user clicks on close [X]
  -     (in the upper right-hand corner of the model popup
  -     window)
  */
    $(document).ready(function() { 
      /* #--- 1.
      - Retrieve a list of the kinds of pets from the database in
        order to initialize the selection list and set the default
        category using the one passed from a submitted form via
        $_POST['interest'] */
      var sel = <?php echo "\"{$_POST['interest']}\""?>;
      $.get("AJAX_live_list.php?sel=" + sel, function(data, status){
        $("#petList").html(data);
      });
      /* #--- 2.
      - Update the selection list from database, when the user
        clicks on the list */
      $("#petList").on("click", function() {
        var sel = document.getElementById('petList');
        var opt = sel.value;
        /* Return list with selected type shown */
        $.get("AJAX_live_list.php?sel=" + opt, function(data, status) {
          $("#petList").html(data);
        });
      });  
      /* #--- 3.
      - Open the picture modal popup window when the user clicks on
        the small pet picture */
      $(".showPic").on("click", function() { 
        var img=$(this).attr("data-id");
        var html="<img src='./media/" + img + "' border='0' />";
        $('.pictureImg').html(html);
      });
      /* #--- 4.
      - Open the video modal popup window when the user clicks on
        the YouTube icon */
      $(".showVid").on("click", function() { 
        var vid=$(this).attr("data-id");
        var html="<iframe width='1050' height='592' src=\""
          + vid + "?&autoplay=1\" title='YouTube video player' " 
          + "frameborder='0' allow='accelerometer; autoplay; "
          + "clipboard-write; encrypted-media; gyroscope; "
          + "picture-in-picture' allowfullscreen></iframe>";
        $('.videoSrc').html(html);
      });
      /* #--- 5.
      - Stop the YouTube video when the user clicks on close [X]
          (in the upper right-hand corner of the model popup
          window) */
      $('#closeVideo').on("click", function(event) {
        event.preventDefault();
        $('.videoSrc').children('iframe').attr('src', '');
      });
    });
  </script>
</head>
<body>
<div style="text-align: center">
  <img src="media/red-white-awning.jpg" height="100" width="1000" alt="awning" />
  <?php echo "<h3>$Welcome</h3>" ?>
</div>
<div id='page'>
  <!-- #--- 6.
    Add an HTML form with a 'submit' button so that the user may
    choose a different kind of pet (the list of the kinds of pets
    is populated via AJAX)
  -->
  <p>
    <form id="petKind" action='<?php echo $showPets; ?>' method='POST'>
      <button type="submit" form="petKind">
        Select another kind of pet?
      </button>
      <select id='petList' name='interest'> </select>
    </form>
  </p>
<?php
  include("basePet.php");

  $cxn = mysqli_connect($host,$user,$passwd,$dbname)
         or die ("couldn't connect to server");

  /* Select pets of the given type */
  $query = "SELECT * FROM Pet                          #25
            WHERE petType=\"{$_POST['interest']}\"";   #26
  $result = mysqli_query($cxn,$query)
            or die ("Couldn't execute query.");

  /* Display results in a table */
  echo "<table cellspacing='10' border='0' cellpadding='0' 
              width='100%'>";
  echo "<tr><td colspan='6' class='t' style='text-align: right'>
              Click on small picture to see full size image or
                click on play button to play video. <hr /></td></tr>\n";
  while($row = mysqli_fetch_assoc($result))            #36
  {
    $f_price = number_format($row['price'],2);

    /* check whether pet comes in colors */
    $query = "SELECT * FROM Color 
              WHERE petName='{$row['petName']}'";     #42
    $result2 = mysqli_query($cxn,$query) 
              or die(mysqli_error($cxn));             #44
    $ncolors = mysqli_num_rows($result2);             #45
    $row2 = mysqli_fetch_assoc($result2);

    /* display row for each pet */
    echo "<tr>\n";
    echo "  <td><h3>{$row['petID']}</h3></td>\n";
    echo "  <td style='font-weight: bold;
      font-size: 1.1em'><h3>{$row['petName']}</h3></td>\n";
    echo "  <td><h4>{$row['petDescription']}<h4></td>\n";

    /* display picture if pet does not come in colors */
    if( $ncolors <= 1 )                                #54
    {
      /* #--- 7.
      - Insert a small pet picture so that the user may click on
        the picture to show the full-size image in a modal popup
        window */
      echo "  <td>\n
                <a href='#pictureModal' class='showPic'
                  data-id='{$row['pix']}' data-toggle='modal'>\n
                  <img src='./media/{$row['pix']}' border='0'
                    width='100' height='80' />\n
                </a>\n
              </td>\n";
      /* #--- 8.
      - Insert a YouTube icon so that the user may click on the
        icon to start the YouTube video in a modal popup window */
        echo "  <td>\n
                <a href='#videoModal' class='showVid'
                  data-id='{$row2['videoSrc']}' data-toggle='modal'>\n
                  <img src='./media/youtube-logo-icon.png' border='0'
                    width='100' height='80' />\n
                </a>\n
              </td>\n";
    } else {
      echo "  <td><span style='width: 100px; height: 80px;'>&nbsp;
        </span></td>\n";
      echo "  <td><span style='width: 100px; height: 80px;'>&nbsp;
        </span></td>\n";
    }
    echo "  <td class='t' align='right'>\$$f_price</td>\n";
    echo "</tr>\n";

    /* display a row for each color  */
    if($ncolors > 1 )                                  #65
    {
      do
      {
      /* #--- 9.
      - Insert a small pet picture so that the user may click on
        the picture to show the full-size image in a modal popup
        window */
        echo "<tr><td colspan=2>&nbsp;</td>\n
                <td><h4>{$row2['petColor']}</h4></td>\n
                <td>\n
                  <a href='#pictureModal' class='showPic'
                    data-id='{$row2['pix']}' data-toggle='modal'>\n
                    <img src='./media/{$row2['pix']}' border='0'
                      width='100' height='80' />\n
                  </a>\n
                </td>\n";
      /* #--- 10.
      - Insert a YouTube icon so that the user may click on the
        icon to start the YouTube video in a modal popup window */
        echo "  <td>\n
                <a href='#videoModal' class='showVid'
                  data-id='{$row2['videoSrc']}' data-toggle='modal'>\n
                  <img src='./media/youtube-logo-icon.png' border='0'
                    width='100' height='80' />\n
                </a>\n
              </td>\n";
      } while($row2 = mysqli_fetch_assoc($result2));
    }
    echo "<tr><td colspan='6'><hr /></td></tr>\n";
  }
  echo "</table>\n";
?>
</div>
<!-- #--- 11.
  Using the bootstrap CSS properties, add a modal pop window for
  the full-size picture of the pet
-->
<!-- Picture Modal -->
<div class="modal fade" id="pictureModal" tabindex="-1" role="dialog" 
    aria-labelledby="pictureImage" aria-hidden="true">
  <div class="modal-dialog" style="width: 100%; text-align: center;">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header">
        <button type="button" class="close" 
            data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="pictureLabel">
          Pet Image
        </h4>
      </div>
      
      <!-- Modal Body -->
      <div class="modal-body">
        <div class="pictureImg">
        </div> 
      </div>
        
    </div>
  </div>
</div>
<!-- #--- 12.
  Using the bootstrap CSS properties, add a modal pop window for
  the full-size picture of the pet
-->
<!-- Video Modal -->
<div class="modal fade" id="videoModal" tabindex="-1" role="dialog" 
    aria-labelledby="videoEmbed" aria-hidden="true">
  <div class="modal-dialog" style="width: 100%; text-align: center;">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header">
        <button type="button" class="close" id="closeVideo"
            data-dismiss="modal">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="videoLabel">
          Pet Video
        </h4>
      </div>
      
      <!-- Modal Body -->
      <div class="modal-body">
        <div class="videoSrc">
        </div> 
      </div>
        
    </div>
  </div>
</div>
<br>
<table class="rtt">
  <tr>
    <td class="rtd">Return to: &nbsp;</td>
    <td class="rtd"><a href="Pet_Store_Application.html">Pet Store Applications menu</a></td>
    <td class="rtd"><a href="<?php echo $petShop; ?>">Pet Store Welcome page</a></td>
    <td class="rtd"><a href="<?php echo $petCtlg; ?>">Pet Catalog - Catagories</a></td>
  </tr>
</table>
</body></html>
