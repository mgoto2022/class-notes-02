<?php
 /* Program: ChoosePetName.php
  * Desc:    Allows the user to enter the information for
  *          the new pet. IF the category is new, it's entered
  *          into the database.  
  */
if (@$_POST['newbutton'] == "Return to category page"   #7
    or @$_POST['newbutton'] == "Cancel")
{
   header("Location: ChoosePetCat.php");
}
include("basePet.php");
include("functions.php");                               #13
$cxn = mysqli_connect($host,$user,$passwd,$dbname)      #14
       or die ("Couldn't connect to server");
/* If new was selected for pet category, check if 
   category name and description were filled in. */
if(trim($_POST['category']) == "new")	                  #18
{
  $_POST['category']=trim($_POST['newCat']);            #20
  if(empty($_POST['newCat'])                            #21
    or empty($_POST['newDesc']) )
  {
     include("NewCat_form.php");	                      #24
     exit();	                                          #25
  }
  else	                                                #27
  {
    addNewType($_POST['newCat'],$_POST['newDesc'],$cxn);  #29
  }
}	                                                      #31
include("NewName_form.php");                            #32
?>
