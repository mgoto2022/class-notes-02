
--
-- Drop Database: MemberDirectory
--
DROP DATABASE IF EXISTS MemberDirectory;

--
-- Create Database: MemberDirectory;
--
CREATE DATABASE MemberDirectory /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE MemberDirectory;

--
-- Create Table: Member
--
CREATE TABLE Member
  (loginName VARCHAR(80) 
  ,password CHAR(255) NOT NULL DEFAULT("password")
  ,createDate DATE NOT NULL DEFAULT NOW()
  ,lastName VARCHAR(20) NOT NULL
  ,firstName VARCHAR(40) NOT NULL
  ,street VARCHAR(50) NOT NULL
  ,city VARCHAR(50) NOT NULL
  ,state CHAR(2) NOT NULL
  ,zip CHAR(10) NOT NULL
  ,email VARCHAR(50) NOT NULL
  ,phone VARCHAR(15) NOT NULL
  ,fax VARCHAR(15) DEFAULT("")
  ,staff CHAR(2) DEFAULT("")
  ,PRIMARY KEY (loginName) ); 

--
-- Create Table: Login
--
CREATE TABLE Login
  (loginName VARCHAR(80) 
  ,loginTime DATETIME NOT NULL DEFAULT NOW()
  ,PRIMARY KEY (loginName) );
