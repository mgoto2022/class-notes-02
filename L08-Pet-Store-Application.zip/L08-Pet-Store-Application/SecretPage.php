<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Members Only Specials</title>
  <style>
    .button {
      background-color: white;
      border-radius: 8px;
      font-size: 20px;
    }
  </style>
</head>

<body>
<div style="text-align: center">
  <img src="media/red-white-awning.jpg" height="100" width="1000" alt="awning" />
</div>
<?php
  session_start();
  if ($_SESSION['auth'] != 'yes') {
    header("Location: Login.php");
    exit();
  }
?>
<h2>Members Only Specials</h2>
<p>
  <ul style="line-height:240%">
    <li>5% off beagle dogs - present coupon code:  d12345</li>
    <li>3% off siamese cats - present coupon code:  d67890</li>
  </ul>
</p>
<br>&nbsp;
<?php
  if ($_SESSION['staff'] == 'MC') {
    echo "<br>&nbsp;<br>";
    echo "<h4>Staff Functions</h4>";
    echo "<a href='ChoosePetCat.php'>\n";
    echo "  <button class='button'>Add new Pets</button></a>\n";
  }
?>
</body>
</html>
