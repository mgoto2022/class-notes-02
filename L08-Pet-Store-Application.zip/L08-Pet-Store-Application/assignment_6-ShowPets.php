<?php
  /* Program: ShowPets.php
   * Desc:    Displays all the pets in a category. The
   *          category is passed in a variable from a 
   *          submitted form. A "Select another kind of
   *          pet?" button and a select list of the kinds
   *          of pets uses AJAX to obtain the latest list
   *          of pet categries.
   * 
   *          The information for each pet is displayed on
   *          a single line, unless the pet comes in more
   *          than one color. If the pet does come in
   *          colors, a single line is displayed without a
   *          picture or video icon, and a line for each
   *          color, with pictures/icons, is displayed
   *          following the single line. Small pictures/
   *          icons are displayed so that a user may click
   *          on them to show modal popup windows.
   */
  $petCtlg = "assignment_6-PetCtlg.php";
  $petShop = "assignment_6-PetShop.php";
?>
<html>
<head>
  <title>Pet Catalog</title>
  <style>
    #page { margin: 12px; }
    .rtt { border-style: solid; margin: 8px; outline: 2px solid grey; }
    .rtd { padding: 10px; }
  </style>
  <!---
  - The following 'libraries' support modal windows and AJAX --->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="http://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
  /*
  - Add JavaScript routines to:
  -   Retrieve a list of the kinds of pets from the database in
  -     order to initialize the selection list
  -   Update the selection list from database, when the user
  -     clicks on the list
  -   Open the picture modal popup window when the user clicks on
  -     the small pet picture
  -   Open the video modal popup window when the user clicks on
  -     the YouTube icon
  -   Stop the YouTube video when the user clicks on close [X]
  -     (in the upper right-hand corner of the model popup
  -     window)
  */
    $(document).ready(function() { 
      /* #--- 1.
      - Retrieve a list of the kinds of pets from the database in
        order to initialize the selection list and set the default
        category using the one passed from a submitted form via
        $_POST['interest'] */
      
      
      
      
      /* #--- 2.
      - Update the selection list from database, when the user
        clicks on the list */








      /* #--- 3.
      - Open the picture modal popup window when the user clicks on
        the small pet picture */





      /* #--- 4.
      - Open the video modal popup window when the user clicks on
        the YouTube icon */









      /* #--- 5.
      - Stop the YouTube video when the user clicks on close [X]
        (in the upper right-hand corner of the model popup
        window) */




    });
  </script>
</head>
<body>
<div style="text-align: center">
  <img src="media/red-white-awning.jpg" height="100" width="1000" alt="awning" />
</div>
<div id='page'>
  <!-- #--- 6.
    Add an HTML form with a 'submit' button so that the user may
    choose a different kind of pet (the list of the kinds of pets
    is populated via AJAX)
  -->








<?php
  include("basePet.php");

  $cxn = mysqli_connect($host,$user,$passwd,$dbname)
         or die ("couldn't connect to server");

  /* Select pets of the given type */
  $query = "SELECT * FROM Pet                          #25
            WHERE petType=\"{$_POST['interest']}\"";   #26
  $result = mysqli_query($cxn,$query)
            or die ("Couldn't execute query.");

  /* Display results in a table */
  echo "<table cellspacing='10' border='0' cellpadding='0' 
              width='100%'>";
  echo "<tr><td colspan='6' style='text-align: right'>
              Click on small picture to see full size image or
                click on play button to play video. <hr /></td></tr>\n";
  while($row = mysqli_fetch_assoc($result))            #36
  {
    $f_price = number_format($row['price'],2);

    /* check whether pet comes in colors */
    $query = "SELECT * FROM Color 
              WHERE petName='{$row['petName']}'";     #42
    $result2 = mysqli_query($cxn,$query) 
              or die(mysqli_error($cxn));             #44
    $ncolors = mysqli_num_rows($result2);             #45
    $row2 = mysqli_fetch_assoc($result2);

    /* display row for each pet */
    echo "<tr>\n";
    echo "  <td>{$row['petID']}</td>\n";
    echo "  <td style='font-weight: bold;
      font-size: 1.1em'>{$row['petName']}</td>\n";
    echo "  <td>{$row['petDescription']}</td>\n";

    /* display picture if pet does not come in colors */
    if( $ncolors <= 1 )                                #54
    {
      /* #--- 7.
      - Insert a small pet picture so that the user may click on
        the picture to show the full-size image in a modal popup
        window */







      /* #--- 8.
      - Insert a YouTube icon so that the user may click on the
        icon to start the YouTube video in a modal popup window */







    } else {
      echo "  <td><span style='width: 100px; height: 80px;'>&nbsp;
        </span></td>\n";
      echo "  <td><span style='width: 100px; height: 80px;'>&nbsp;
        </span></td>\n";
    }
    echo "  <td align='right'>\$$f_price</td>\n";
    echo "</tr>\n";

    /* display a row for each color  */
    if($ncolors > 1 )                                  #65
    {
      do
      {
      /* #--- 9.
      - Insert a small pet picture so that the user may click on
        the picture to show the full-size image in a modal popup
        window */









      /* #--- 10.
      - Insert a YouTube icon so that the user may click on the
        icon to start the YouTube video in a modal popup window */







      } while($row2 = mysqli_fetch_assoc($result2));
    }
    echo "<tr><td colspan='6'><hr /></td></tr>\n";
  }
  echo "</table>\n";
?>
</div>
<!-- #--- 11.
  Using the bootstrap CSS properties, add a modal pop window for
  the full-size picture of the pet
-->


























<!-- #--- 12.
  Using the bootstrap CSS properties, add a modal pop window for
  the full-size picture of the pet
-->


























<br>
<table class="rtt">
  <tr>
    <td class="rtd">Return to: &nbsp;</td>
    <td class="rtd"><a href="Pet_Store_Application.html">Pet Store Applications menu</a></td>
    <td class="rtd"><a href="<php echo $petShop; ?>">Pet Store Welcome page</a></td>
    <td class="rtd"><a href="<php echo $petCtlg; ?>">Pet Catalog - Catagories</a></td>
  </tr>
</table>
</body></html>
