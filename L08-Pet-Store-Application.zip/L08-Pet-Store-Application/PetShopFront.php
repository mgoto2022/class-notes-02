<?php
  /* Program: PetShopFront.php
   * Desc:    Displays opening page for Pet Store.
   */
?>
<html>
<head><title>Pet Store Welcome Page</title></head>
<body>
<div style="text-align: center">
  <img src="media/red-white-awning.jpg" alt="awning" />
  <img src="media/pet-store.jpg" alt="Pet Store">
  <h1>Welcome</h1>
  <p style="margin-top: 20pt">
  <a href="PetCatalog.php">
    <img src="media/cat-scottish_fold-gray_white.jpg"
       width="500" height="530" alt="kitten picture" />
  </a>
  </p>
  <h2>Looking for a new friend?</h2>
  <p>Check out our <a href="PetCatalog.php">Pet Catalog.</a>
  <br> We may have just what you're looking for.</p>
</div>
</body></html>
