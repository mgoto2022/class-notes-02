<?php
  /* Program: PetShopFront.php
   * Desc:    Displays opening page for Pet Store.
   */
?>
<html>
<head>
  <title>Pet Store Welcome Page</title>
  <style type='text/css'>
    h1 { font-size: 80px; font-weight: bolder; }
    h2 { font-size: 40px; font-weight: bolder; }
    h3 { font-size: 35px; font-weight: bolder; }
    h4 { font-size: 30px; font-weight: bolder; }
    p  { font-size: 20px; font-family: Arial, sans-serif; }
    </style>
</head>
<body>
<div style="text-align: center">
  <img src="media/red-white-awning.jpg" alt="awning" />
  <img src="media/pet-store.jpg" alt="Pet Store">
  <h1>Welcome</h1>
  <p style="margin-top: 20pt">
  <a href="PetCatalog.php">
    <img src="media/cat-scottish_fold-gray_white.jpg"
       width="400" height="424" alt="kitten picture" />
  </a>
  </p>
  <h2>Looking for a new friend?</h2>
  <h4>Check out our <a href="PetCatalog.php">Pet Catalog.</a>
  <br> We may have just what you're looking for.</h4>
</div>
</body></html>
