<?php
  $host = "localhost";
  $user = "root";
  $passwd = "";
  $dbname = "MemberDirectory";
?>