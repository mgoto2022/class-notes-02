<?php
  /* Program: NewCat_form
   * Desc:    Displays a form to collect a category name
   *          and description.
   */
?>
<html>
<head>
  <title>New Category Form</title>
  <style type='text/css'>
    <!--
    .field { padding-top: .5em; }
    label { font-weight: bold; float: left; width: 18%;
            margin-right: 1em; text-align: right; }
    -->
    .rtt { border-style: solid; outline: 2px solid grey; }
    .rtd { padding: 10px; }
  </style> 
</head>
<body style="padding: 1em">
<div style="text-align: center">
  <img src="media/red-white-awning.jpg" height="100" width="1000" alt="awning" />
</div>
<h3>Either the category name or the category description 
    was left blank. You must enter both.</h3>
<form action=<?php echo "$_SERVER[PHP_SELF]" ?> method="post">
  <div class="field">
    <label for="newCat">Category name: </label>
     <input type="text" name="newCat" id="newCat"
        size="20" maxlength="20"
        value="<?php echo $_POST['newCat'] ?>" /></div>
  <div class="field">
    <label for="newDesc">Category description: </label>
     <input type="text" name="newDesc" id="newDesc"
        value="<?php echo $_POST['newDesc'] ?>" 
        size="70%" maxlength="255" /></div>
  <input type="hidden" name="category" value="new">
   <p><input type="submit" name="newbutton" 
         value="Enter new category">
      <input type="submit" name="newbutton" 
         value="Return to category page">
</form>
<br><br>
<table class="rtt">
  <tr>
    <td class="rtd">Return to: &nbsp;</td>
    <td class="rtd"><a href="PetShopFrontMembers.php">Pet Store Welcome page</a></td>
    <td class="rtd"><a href="ChoosePetCat.php">Choose Pet Catagory</a></td>
  </tr>
</table>
</body></html>
