<?php
  /* Program: ShowPets.php
   * Desc:    Displays all the pets in a category. 
   *          Category is passed in a variable from a 
   *          form. The information for each pet is  
   *          displayed on a single line, unless the pet  
   *          comes in more than one color. If the pet 
   *          comes in colors, a single line is displayed  
   *          without a picture, and a line for each color,
   *          with pictures, is displayed following the 
   *          single line. Small pictures are displayed, 
   *          which are links to larger pictures.
   *          Finally, the petName (the breed) field
   *          contains a link to ShowPetsMore.php.
   */
?>
<html>
<head>
  <title>Pet Catalog</title>
  <style>
    h1 { font-size: 80px; font-weight: bolder; }
    h2 { font-size: 40px; font-weight: bolder; }
    h3 { font-size: 35px; font-weight: bolder; }
    h4 { font-size: 30px; font-weight: bolder; }
    .t { font-size: 20px; font-family: Arial, sans-serif; }
    #page { margin: 12px; }
    .rtt { border-style: solid; margin: 8px; outline: 2px solid grey; }
    .rtd { padding: 10px; }
  </style>
</head>
<body>
<div style="text-align: center">
  <img src="media/red-white-awning.jpg" height="100" width="1000" alt="awning" />
</div>
<div id='page'>
<?php
  include("basePet.php");

  $cxn = mysqli_connect($host,$user,$passwd,$dbname)
         or die ("couldn't connect to server");

  /* Select pets of the given type */
  $query = "SELECT * FROM Pet                          #25
            WHERE petType=\"{$_POST['interest']}\"";   #26
  $result = mysqli_query($cxn,$query)
            or die ("Couldn't execute query.");

  /* Display results in a table */
  echo "<table cellspacing='10' border='0' cellpadding='0' 
              width='100%'>";
  echo "<tr><td colspan='6' class='t' style='text-align: right'>
              Click on small picture to see full size image or
                click on play button to play video. <hr /></td></tr>\n";
  while($row = mysqli_fetch_assoc($result))            #36
  {
    $f_price = number_format($row['price'],2);

    /* check whether pet comes in colors */
    $query = "SELECT * FROM Color 
              WHERE petName='{$row['petName']}'";     #42
    $result2 = mysqli_query($cxn,$query) 
              or die(mysqli_error($cxn));             #44
    $ncolors = mysqli_num_rows($result2);             #45
    $row2 = mysqli_fetch_assoc($result2);

    /* display row for each pet */
    echo "<tr>\n";
    echo "  <td><h3>{$row['petID']}</h3></td>\n";
    echo "  <td style='font-weight: bold;
      font-size: 1.1em'><h3>{$row['petName']}</h3></td>\n";
    echo "  <td><h4>{$row['petDescription']}<h4></td>\n";

    /* display picture if pet does not come in colors */
    if( $ncolors <= 1 )                                #54
    {
      echo "  <td><a href='./media/{$row['pix']}'
                          border='0'>\n
                  <img src='./media/{$row['pix']}' 
                    border='0' width='100' height='80' />\n
                </a></td>\n";
      echo "  <td>\n","<iframe width='400' height='225' src=\"",
              $row2['videoSrc'],"\" title='YouTube video player'
              frameborder='0' allow='accelerometer; autoplay;
              clipboard-write; encrypted-media; gyroscope;
              picture-in-picture' allowfullscreen></iframe>\n",
              "</td>\n";
    } else {
      echo "  <td><span style='width: 100px; height: 80px;'>&nbsp;
        </span></td>\n";
      echo "  <td><span style='width: 100px; height: 80px;'>&nbsp;
        </span></td>\n";
    }
    echo "  <td class='t' align='right'>\$$f_price</td>\n";
    echo "</tr>\n";

    /* display a row for each color  */
    if($ncolors > 1 )                                  #65
    {
      do
      {
        echo "<tr><td colspan=2>&nbsp;</td>\n
                  <td><h4>{$row2['petColor']}</h4></td>\n
                  <td><a href='./media/{$row2['pix']}'
                            border='0'>\n
                      <img src='./media/{$row2['pix']}' 
                          border='0' width='100' height='80' />\n
                </a></td>\n";
        echo "  <td>\n","<iframe width='400' height='225' src=\"",
          $row2['videoSrc'],"\" title='YouTube video player'
          frameborder='0' allow='accelerometer; autoplay;
          clipboard-write; encrypted-media; gyroscope;
          picture-in-picture' allowfullscreen></iframe>\n",
          "</td>\n";
      } while($row2 = mysqli_fetch_assoc($result2));
    }
    echo "<tr><td colspan='6'><hr /></td></tr>\n";
  }
  echo "</table>\n";
?>
</div>
<br>
<table class="rtt">
  <tr>
    <td class="rtd">Return to: &nbsp;</td>
    <td class="rtd"><a href="Pet_Store_Application.html">Pet Store Applications menu</a></td>
    <td class="rtd"><a href="PetShopFrontMembers.php">Pet Store Welcome page</a></td>
    <td class="rtd"><a href="PetCatalog.php">Pet Catalog - Catagories</a></td>
  </tr>
</table>
</body></html>
