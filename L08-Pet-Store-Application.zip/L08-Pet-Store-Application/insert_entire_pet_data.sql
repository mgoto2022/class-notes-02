USE `PetCatalog`;

--
-- Cats:  Insert data for Table: Pet
--
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (2001,'Burmese','cat','small, affectionate, loyal, cat',700.00,
  'cat-burmese-light_brown.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (2002,'Persian','cat','gentle, quiet, docile, cat',1400.00,
  'cat-persian-black.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (2003,'Scottish Fold','cat','playful, calm, adaptable, cat',350.00,
  'cat-scottish_fold-gray_brown.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (2004,'Siamese','cat','intelligent, talkative, social, cat',700.00,
  'cat-siamese-white_black.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (2005,'Tiger','cat','solitary, powerful, colorful big cat',7500.00,
  'cat-tiger-orange-black-white.webp');
  
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType ( petType,typeDescription)
 VALUES ('cat','Cats are very sensitive to their interpersonal space.  They often do not have strict social hierarchies. They are also subtle in their display of friendly, or affiliative behaviors. Once aroused into threatening behaviors, cats can remain so for quite a long time.');
  
--
-- Insert data for Table: Color
--
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Burmese','light brown','cat-burmese-light_brown.jpg','https://www.youtube.com/embed/cRBEL57B6ok');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Persian','black','cat-persian-black.jpg','https://www.youtube.com/embed/QqZ7YkTdGIY');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Scottish Fold','gray brown','cat-scottish_fold-gray_brown.jpg','https://www.youtube.com/embed/mlNJMpBtNzo');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Scottish Fold','gray white','cat-scottish_fold-gray_white.jpg','https://www.youtube.com/embed/Qx6z8UQEYSg');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Siamese','white black','cat-siamese-white_black.jpg','https://www.youtube.com/embed/2LyVbxmMxqE');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Tiger','orange black white','cat-tiger-orange-black-white.webp','https://www.youtube.com/embed/FK3dav4bA4s');

--
-- Horses:  Insert data for Table: Pet
--
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (4001,"Clydesdale","horse","large powerful horse",4000.00,
  "horse-clydesdale-brown_white_legs.jpg");
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (4002,"Pegasus","horse","wise winged mare",80000.00,"horse-pegasus-white.jpg");
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (4003,"Unicorn","horse","peaceful steed with spiral forehead horn",50000.00,"horse-unicorn-white.jpg");
   
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType ( petType,typeDescription)
 VALUES ('horse','Horses have oval-shaped hooves, long tails, short hair, long slender legs, muscular and deep torso build, long thick necks, and large elongated heads. The mane is a region of coarse hairs, which extends along the dorsal side of the neck in both domestic and wild species.');
   
--
-- Insert data for Table: Color
--
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Clydesdale','brown white','horse-clydesdale-brown_white_legs.jpg','https://www.youtube.com/embed/_m7iKHUWq8M');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Pegasus','white','horse-pegasus-white.jpg','https://www.youtube.com/embed/sMGgc9nPtQU');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Unicorn','white','horse-unicorn-white.jpg','https://www.youtube.com/embed/uWkz0IggQjw');

--
-- Dogs:  Insert data for Table: Pet (add VALUES to 3rd REPLACE)
--
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (3001,'Beagle','dog','small scent hound dog',500.00,
 'dog-beagle-white_brown_black.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (3002,'Pomeranian','dog','smart, curious, energetic, feisty, bold dog',1400.00,
 'dog-pomeranian-red-white.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (3003,'Shiba Inu','dog','alert, loyal, lively dog',1800.00,
 'dog-shiba-inu-red-white.png');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (3016,'Yorkshire Terrier','dog','small feisty, tenacious, vermin hunters',2000.00,'dog-yorkshire_terrier-brown_black.jpg');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */
  
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType ( petType,typeDescription)
 VALUES ('dog','Dogs’ sense of smell is at least 40x better than ours.  Some have sich good noses that they can sniff our medical problems.  Some dogs are incredible swimmers.  Dogs pant to cool down instead of sweating.  Along with their noses, their hearing is super sensitive.');
  
--
-- Insert data for Table: Color (add VALUES to 3rd REPLACE)
--
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Beagle','white brown black','dog-beagle-white_brown_black.jpg','https://www.youtube.com/embed/SSoV5gDGeN4');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Pomeranian','red white','dog-pomeranian-red-white.jpg','https://www.youtube.com/embed/Sv0GdSevNw8');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Shiba Inu','red white','dog-shiba-inu-red-white.png','https://www.youtube.com/embed/bJP7XuHjp-Q');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Yorkshire Terrier','brown black','dog-yorkshire_terrier-brown_black.jpg','https://www.youtube.com/embed/HVjXBTnzTs8');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */

--
-- Birds:  Insert data for Table: Pet (add VALUES to 2nd REPLACE)
--
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (1001,'Cockatoo','bird','small, playful, bird',3000.00,'bird-cockatoo-white.jpg');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Pet
 ( petID,petName,petType,petDescription,price,pix)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */
--
-- Insert data for Table: PetType
--
REPLACE INTO PetType ( petType,typeDescription)
 VALUES ('bird','Pet birds are very affectionate and develop a close bond with their owners.  These birds become “possessive” and tend to bond to one person in particular so it is a good idea to keep the bird interacting with all the family members.  They are very playful and have entertaining personalities.');

--
-- Insert data for Table: Color  (add VALUES to 2nd REPLACE)
--
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Cockatoo','white','bird-cockatoo-white.jpg','https://www.youtube.com/embed/qnkMobV-GvU');
/* (remove this comment line when VALUES are filled-in)
REPLACE INTO Color
 ( petName,petColor,pix,videoSrc)
 VALUES ();
/* (can be removed if VALUES are filled-in)  */
