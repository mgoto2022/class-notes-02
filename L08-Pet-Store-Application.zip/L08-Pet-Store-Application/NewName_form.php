<?php
 /*  Program name: NewName_form
  *  Description:  Script displays a form that asks for
  *                the new pet information.
  */
$labels = array( "petName" => "Pet Name: ",
                 "petDescription" => "Pet Description: ",
                 "price" => "Price",
                 "pix" => "Picture file name: ",
                 "petColor" => "Pet color (optional)",
                 "videoSrc" => "Pet video (optional)"); #10
if(isset($_POST['category']))                           #11
{
    $category = $_POST['category'];
}
else
{
    $category = $_POST['newCat'];
}
?>
<html>
<head>
  <title>New Pet Information Form</title>
  <style type='text/css'>
    <!--
    form { margin: 1em; padding: 0; }
    .field { padding-top: .5em; }
    label { font-weight: bold; float: left; width: 18%;
            margin-right: 1em; text-align: right; }
    #submit { margin-top: 1em; }
    -->
    .rtt { border-style: solid; outline: 2px solid grey; }
    .rtd { padding: 10px; }
  </style> 
</head>

<body>
<div style="text-align: center">
  <img src="media/red-white-awning.jpg" height="100" width="1000" alt="awning" />
</div>
<form action="AddPet.php" method="post">
<?php
 echo "<h4>Pet Information</h4>";                       #37
 echo "<div class='field'>
        <label>Pet Category:</label>
         <b>$category</b></div>\n";
 foreach($labels as $field => $label)
 {
   echo "<div class='field'>
          <label for='$field'>$label</label>
           <input type='text' name='$field' id='$field'
             size='65' maxlength='65' value='".@$$field."' /></div>\n";
 }
?>
<div id="submit">
 <input type='hidden' name='newCat' 
              value='<?php echo $category ?>' /> 
 <input type='submit' value='Submit Pet Name' />
 <input type='submit' name='newbutton' value='Cancel' />
</div></form>
<br><br>
<table class="rtt">
  <tr>
    <td class="rtd">Return to: &nbsp;</td>
    <td class="rtd"><a href="PetShopFrontMembers.php">Pet Store Welcome page</a></td>
    <td class="rtd"><a href="ChoosePetCat.php">Choose Pet Catagory</a></td>
  </tr>
</table>
</body></html>


