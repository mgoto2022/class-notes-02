USE `PetCatalog`;

--
-- Delete reptile data from Table: Pet
--
DELETE FROM Pet WHERE petType = 'reptile';

--
-- Delete reptile data from Table: PetType
--
DELETE FROM PetType WHERE petType = 'reptile';

--
-- Delete reptile data from Table: Color
--
DELETE FROM Color WHERE petName = 'Leopard Gecko';
DELETE FROM Color WHERE petName = 'Bearded Dragon';