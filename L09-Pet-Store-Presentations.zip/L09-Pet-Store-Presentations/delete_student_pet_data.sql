USE `PetCatalog`;

--
-- Delete data from Table: Pet
--
DELETE FROM Pet WHERE petName = 'Peregrine Falcon';
DELETE FROM Pet WHERE petName = 'Norwegian Lundehund';
DELETE FROM Pet WHERE petName = 'Sphynx';
DELETE FROM Pet WHERE petName = 'Dwarf Crocodile';

--
-- Delete data from Table: Color
--
DELETE FROM Color WHERE petName = 'Peregrine Falcon';
DELETE FROM Color WHERE petName = 'Norwegian Lundehund';
DELETE FROM Color WHERE petName = 'Sphynx';
DELETE FROM Color WHERE petName = 'Dwarf Crocodile';