USE `PetCatalog`;

--
-- Insert data for Table: Pet
--
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (1008,'Peregrine Falcon','bird','fast (~200 mph) bird of prey',2000.00,'bird-peregrine-falcon-white-brown.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (2008,'Sphynx','cat','friendly, loving and energetic show-off cat',2000.00,'cat-sphynx-hairless-gray.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (3003,'Norwegian Lundehund','dog','six-toed, cliff hunting dog',2000.00,'dog-norwegian-lundehund-orange-white.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (5004,'Dwarf Crocodile','reptile','short, blunt muzzle, small black body with a yellow belly crocodile',400.00,'reptile-dwarf-crocodile-black-yellow.jpg');

--
-- Insert data for Table: Color
--
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Peregrine Falcon','white brown','bird-peregrine-falcon-white-brown.jpg','https://www.youtube.com/embed/r7lglchYNew');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Sphynx','hairless grey','cat-sphynx-hairless-gray.jpg','https://www.youtube.com/embed/o_GCxjP1OYk');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Norwegian Lundehund','orange white','dog-norwegian-lundehund-orange-white.jpg','https://www.youtube.com/embed/8KkSxGSY9Sk');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Dwarf Crocodile','black yellow','reptile-dwarf-crocodile-black-yellow.jpg','https://www.youtube.com/embed/ekkpWvWjnVE');