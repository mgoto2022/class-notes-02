USE `PetCatalog`;

--
-- Reptiles:  Insert data for Table: Pet
--
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (5001,'Leopard Gecko','reptile','nocturnal, ground-dwelling gecko',50.00,'reptile-leopard-gecko-orange_black.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (5002,'Bearded Dragon','reptile','docile, diurnal, tame lizard',60.00,'reptile-bearded-dragon-orange.png');

--
-- Insert reptile data into Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('reptile','Reptiles include snakes, lizards, turtles and tortoises and most are cold-blooded. All reptiles are vertebrates (have backbones) and have four limbs or are descended from four-limbed animals. Also, reptiles breathe with the aid of lungs.');
 
--
-- Insert data for Table: Color
--
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Leopard Gecko','orange black','reptile-leopard-gecko-orange_black.jpg','https://www.youtube.com/embed/-esD4QuGOLk');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Bearded Dragon','orange','reptile-bearded-dragon-orange.png','https://www.youtube.com/embed/ue0tdiwMD-8');
