USE `PetCatalog`;

--
-- Insert data for Table: Pet
--
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (1008,'Peregrine Falcon','bird','fast (~200 mph) bird of prey',2000.00,'bird-peregrine-falcon-white-brown.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (2008,'Sphynx','cat','friendly, loving and energetic show-off cat',2000.00,'cat-sphynx-hairless-gray.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (3003,'Norwegian Lundehund','dog','six-toed, cliff hunting dog',2000.00,'dog-norwegian-lundehund-orange-white.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (5004,'Dwarf Crocodile','reptile','short, blunt muzzle, small black body with a yellow belly crocodile',400.00,'reptile-dwarf-crocodile-black-yellow.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (5001,'Leopard Gecko','reptile','nocturnal, ground-dwelling gecko',50.00,'reptile-leopard-gecko-orange_black.jpg');
REPLACE INTO Pet ( petID,petName,petType,petDescription,price,pix)
 VALUES (5002,'Bearded Dragon','reptile','docile, diurnal, tame lizard',60.00,'reptile-bearded-dragon-orange.png');

--
-- Insert reptile data into Table: PetType
--
REPLACE INTO PetType
 ( petType,typeDescription)
 VALUES ('reptile','Reptiles include snakes, lizards, turtles and tortoises and most are cold-blooded. All reptiles are vertebrates (have backbones) and have four limbs or are descended from four-limbed animals. Also, reptiles breathe with the aid of lungs.');
 
--
-- Insert data for Table: Color
--
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Peregrine Falcon','white brown','bird-peregrine-falcon-white-brown.jpg','https://www.youtube.com/embed/r7lglchYNew');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Sphynx','hairless grey','cat-sphynx-hairless-gray.jpg','https://www.youtube.com/embed/o_GCxjP1OYk');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Norwegian Lundehund','orange white','dog-norwegian-lundehund-orange-white.jpg','https://www.youtube.com/embed/8KkSxGSY9Sk');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Dwarf Crocodile','black yellow','reptile-dwarf-crocodile-black-yellow.jpg','https://www.youtube.com/embed/ekkpWvWjnVE');
 REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Leopard Gecko','orange black','reptile-leopard-gecko-orange_black.jpg','https://www.youtube.com/embed/-esD4QuGOLk');
REPLACE INTO Color ( petName,petColor,pix,videoSrc)
 VALUES ('Bearded Dragon','orange','reptile-bearded-dragon-orange.png','https://www.youtube.com/embed/ue0tdiwMD-8');